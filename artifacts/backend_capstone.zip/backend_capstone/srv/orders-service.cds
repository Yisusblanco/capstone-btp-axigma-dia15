using cap from '../db/schema';
using { API_BUSINESS_PARTNER as external } from './external/API_BUSINESS_PARTNER';

@impl: './orders-handler.js'
service OrdersService @(path: '/orders') {

  @readonly
  entity Products as projection on cap.Products
    where active = true;

  @(restrict: [
    { grant: 'READ',
      to: ['OrderRead', 'OrderCreate', 'OrderApprove'] },
    { grant: ['CREATE', 'UPDATE', 'submitForApproval'],
      to: 'OrderCreate' },
    { grant: ['receiveApprovalDecision'],
      to: 'OrderApprove' }
  ])
  entity Orders as projection on cap.Orders
    excluding { approvalID }
    actions {
      action submitForApproval()
        returns String;
      action receiveApprovalDecision(
        decision  : String @mandatory,
        approvedBy: String @mandatory,
        remarks   : String
      ) returns String;
    };

  @(restrict: [
    { grant: 'READ',              to: ['OrderRead', 'OrderCreate', 'OrderApprove'] },
    { grant: ['CREATE','UPDATE'], to: 'OrderCreate' }
  ])
  entity OrderItems as projection on cap.OrderItems;

}
