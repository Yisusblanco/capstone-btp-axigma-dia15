const cds = require('@sap/cds');

module.exports = cds.service.impl(async function (srv) {

  const { Orders, OrderItems, Products } = srv.entities;
  const axios = require('axios');

  // ═══════════════════════════════════════════════════════
  // BEFORE CREATE
  // ═══════════════════════════════════════════════════════
  srv.before('CREATE', Orders, async (req) => {
    const order = req.data; 

    const count = await SELECT.one`count(*) as total`.from(Orders);
    const next = (parseInt(count.total) || 0) + 1;
    order.orderNumber = `ORD-${String(next).padStart(5, '0')}`;

    if (!order.items || order.items.length === 0) {
      req.error(400, 'La orden debe tener al menos un ítem');
      return;
    }

    let totalAmount = 0;

    for (const item of order.items) {
      if (!item.product_ID) {
        req.error(400, 'Cada ítem debe tener un producto');
        return;
      }

      const product = await SELECT.one(Products).where({ ID: item.product_ID });

      if (!product) {
        req.error(404, `Producto ${item.product_ID} no encontrado`);
        return;
      }

      if (!product.active) {
        req.error(409, `Producto ${product.description} no está activo`);
        return;
      }

      item.price    = product.unitPrice;
      item.subtotal = (item.qty || 1) * product.unitPrice;
      totalAmount  += item.subtotal;
    }

    order.amount   = totalAmount;
    order.currency = order.currency || 'PEN';
    order.status   = 'PENDING';

    // Enriquecer con datos de S/4HANA Tai Loy via Destination S4HANA
    const bpData = await _validateBusinessPartner(order.customer);
    if (bpData) {
      console.log(`[S4HANA] BP encontrado: ${bpData.BusinessPartner} — ${bpData.BusinessPartnerFullName}`);
      // Opcional: guardar el BP number en remarks si no tiene ya uno
      if (!order.remarks) {
        order.remarks = `BP S4: ${bpData.BusinessPartner}`;
      }
    }

  });

  // ═══════════════════════════════════════════════════════
  // BEFORE UPDATE
  // ═══════════════════════════════════════════════════════
  srv.before('UPDATE', Orders, async (req) => {
    const { ID } = req.data;

    const current = await SELECT.one(Orders).where({ ID });

    if (!current) {
      req.error(404, `Orden ${ID} no encontrada`);
      return;
    }

    const locked = ['IN_APPROVAL', 'APPROVED', 'REJECTED'];
    if (locked.includes(current.status)) {
      req.error(409, `No se puede modificar una orden con status ${current.status}`);
    }
  });

  // ═══════════════════════════════════════════════════════
  // ON submitForApproval
  // ═══════════════════════════════════════════════════════
  srv.on('submitForApproval', Orders, async (req) => {
    const param = req.params[0];
    const ID = typeof param === 'object' ? param.ID : param;

    if (!ID) {
      return req.error(400, 'ID de orden no recibido');
    }

    const order = await SELECT.one(Orders).where({ ID });

    if (!order) {
      return req.error(404, `Orden ${ID} no encontrada`);
    }

    if (order.status !== 'PENDING') {
      return req.error(409,
        `Solo se pueden enviar órdenes en estado PENDING. Estado actual: ${order.status}`
      );
    }

    if (order.amount <= 0) {
      return req.error(400, 'La orden tiene importe cero');
    }

    const instanceID = await _triggerBPA(order, req.user.id);

    await UPDATE(Orders)
      .set({ status: 'IN_APPROVAL', approvalID: instanceID })
      .where({ ID });

    return `Orden ${order.orderNumber} enviada a aprobación. Instance ID: ${instanceID}`;
  });

  // ═══════════════════════════════════════════════════════
  // ON receiveApprovalDecision
  // ═══════════════════════════════════════════════════════
  srv.on('receiveApprovalDecision', Orders, async (req) => {
    const param = req.params[0];
    const ID = typeof param === 'object' ? param.ID : param;

    if (!ID) {
      return req.error(400, 'ID de orden no recibido');
    }

    const { decision, approvedBy, remarks } = req.data;

    // ← aquí estaba el bug: validDecisions no estaba declarado
    const validDecisions = ['APPROVED', 'REJECTED'];
    if (!validDecisions.includes(decision)) {
      return req.error(400,
        `Decision inválida: ${decision}. Valores permitidos: APPROVED, REJECTED`
      );
    }

    const order = await SELECT.one(Orders).where({ ID });

    if (!order) {
      return req.error(404, `Orden ${ID} no encontrada`);
    }

    if (order.status !== 'IN_APPROVAL') {
      return req.error(409,
        `Solo se pueden procesar órdenes en estado IN_APPROVAL. Estado actual: ${order.status}`
      );
    }

    await UPDATE(Orders)
      .set({
        status:     decision,
        approvedBy: approvedBy,
        approvedAt: new Date().toISOString(),
        remarks:    remarks || ''
      })
      .where({ ID });

    order.remarks = remarks || '';           // ← AGREGAR ESTA LÍNEA
    await _notifyViaCPI(order, decision, approvedBy);

    return `Orden ${order.orderNumber} actualizada a ${decision} por ${approvedBy}`;
  });

  // ═══════════════════════════════════════════════════════
  // FUNCIONES PRIVADAS
  // ═══════════════════════════════════════════════════════
  async function _triggerBPA(order, requestedBy) {
        // 1. Obtener token OAuth2 (client credentials) de BPA
        const tokenResponse = await axios.post(
          `${process.env.BPA_UAA_URL}/oauth/token`,
          'grant_type=client_credentials',
          {
            auth: {
              username: process.env.BPA_CLIENT_ID,
              password: process.env.BPA_CLIENT_SECRET
            },
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
          }
        );
        const accessToken = tokenResponse.data.access_token;

        // 2. Armar payload según el schema del trigger
        const payload = {
          definitionId: 'us10.96ccb488trial.capstoneorderapprovalcopy.orderApprovalProcess',
          context: {
            ordernumber:   order.orderNumber,
            customer:      order.customer,
            customeremail: order.customerEmail,
            amount:        order.amount,
            currency:      order.currency,
            requestedby:   requestedBy,
            orderid:       order.ID
          }
        };

        // 3. Invocar el trigger de BPA
        const response = await axios.post(
          `${process.env.BPA_API_URL}/workflow/rest/v1/workflow-instances`,
          payload,
          {
            headers: {
              Authorization: `Bearer ${accessToken}`,
              'Content-Type': 'application/json'
            }
          }
        );

        // 4. Retornar el ID de la instancia creada
        return response.data.id || response.data.instanceId || response.data.workflowInstanceId;
  }

    
  

  async function _notifyViaCPI(order, decision, approvedBy) {
    try {
      // 1. Obtener token OAuth2 (client credentials) del tenant de Integration Suite
      const tokenResponse = await axios.post(
        process.env.CPI_TOKEN_URL,
        'grant_type=client_credentials',
        {
          auth: {
            username: process.env.CPI_CLIENT_ID,
            password: process.env.CPI_CLIENT_SECRET
          },
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        }
      );
      const accessToken = tokenResponse.data.access_token;

      // 2. Armar el payload esperado por el script Groovy del iFlow
      const payload = {
        orderNumber:   order.orderNumber,
        customer:      order.customer,
        customerEmail: order.customerEmail,
        decision:      decision,
        remarks:       order.remarks || '',
        amount:        order.amount,
        currency:      order.currency
      };

      // 3. Invocar el iFlow de notificación
      await axios.post(
        process.env.CPI_IFLOW_URL,
        payload,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          }
        }
      );

      console.log(`[CPI] Notificación enviada para orden ${order.orderNumber} (${decision})`);

    } catch (err) {
      // No bloqueamos la actualización de la orden si CPI falla
      console.log(`[CPI] ⚠ Error al enviar notificación: ${err.message}`);
    }
  }

  // ═══════════════════════════════════════════════════════
  // Validación Business Partner en S/4HANA Tai Loy
  // Destination: S4HANA → Cloud Connector → S/4HANA
  // API: API_BUSINESS_PARTNER (OData V2 estándar SAP)
  // ═══════════════════════════════════════════════════════
  async function _validateBusinessPartner(customerName) {
    try {
      const bp = await cds.connect.to('API_BUSINESS_PARTNER');

      const result = await bp.run(
        SELECT.one('A_BusinessPartner')
          .where({ BusinessPartnerFullName: customerName })
          .columns(
            'BusinessPartner',
            'BusinessPartnerFullName',
            'BusinessPartnerIsBlocked',
            'BusinessPartnerCategory'
          )
      );

      if (result) {
        console.log(`[S4HANA] ✓ BP validado: ${result.BusinessPartner} — ${result.BusinessPartnerFullName}`);
      } else {
        console.log(`[S4HANA] ℹ BP no encontrado para: "${customerName}" — se permite igual`);
      }

      return result;

    } catch (err) {
      // No bloqueamos la creación si S4HANA no responde
      console.log(`[S4HANA] ⚠ No se pudo conectar al BP: ${err.message}`);
      return null;
    }
  }

});