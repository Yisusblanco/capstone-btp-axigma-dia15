/* checksum : 125ca4a4c070451161a396208377d5f9 */
@cds.external : true
@m.IsDefaultEntityContainer : 'true'
@sap.message.scope.supported : 'true'
@sap.supported.formats : 'atom json xlsx'
service API_BUSINESS_PARTNER {};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Dirección de correo electrónico'
entity API_BUSINESS_PARTNER.A_AddressEmailAddress {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº dirección'
  key AddressID : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Número de persona'
  key Person : String(10) not null;
  @sap.display.format : 'NonNegative'
  @sap.label : 'Número actual'
  key OrdinalNumber : String(3) not null;
  @sap.label : 'Direc.por defecto'
  @sap.quickinfo : 'Ind.: Esta dirección es la dirección por defecto'
  IsDefaultEmailAddress : Boolean;
  @sap.label : 'Correo electrónico'
  @sap.quickinfo : 'Dirección de correo electrónico'
  EmailAddress : String(241);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Dir.cor.elec.'
  @sap.quickinfo : 'Campo búsqueda para dirección correo electrónico'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  SearchEmailAddress : String(20);
  @sap.label : 'Comentarios'
  @sap.quickinfo : 'Comentarios referentes al empalme de comunicación'
  AddressCommunicationRemarkText : String(50);
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Número de fax'
entity API_BUSINESS_PARTNER.A_AddressFaxNumber {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº dirección'
  key AddressID : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Número de persona'
  key Person : String(10) not null;
  @sap.display.format : 'NonNegative'
  @sap.label : 'Número actual'
  key OrdinalNumber : String(3) not null;
  @sap.label : 'Nº estándar'
  @sap.quickinfo : 'Dirección remitente estándar en esta clase comunicación'
  IsDefaultFaxNumber : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'País/Región'
  @sap.quickinfo : 'País/región para el número de teléfono/fax'
  FaxCountry : String(3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Fax'
  @sap.quickinfo : 'Número de fax: Prefijo y número'
  FaxNumber : String(30);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Extensión'
  @sap.quickinfo : 'Nº fax: Extensión'
  FaxNumberExtension : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº fax'
  @sap.quickinfo : 'Número de fax completo: Prefijo+número+extensión'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  InternationalFaxNumber : String(30);
  @sap.label : 'Comentarios'
  @sap.quickinfo : 'Comentarios referentes al empalme de comunicación'
  AddressCommunicationRemarkText : String(50);
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'URL de página de inicio'
entity API_BUSINESS_PARTNER.A_AddressHomePageURL {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº dirección'
  key AddressID : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Número de persona'
  key Person : String(10) not null;
  @sap.display.format : 'NonNegative'
  @sap.label : 'Número actual'
  key OrdinalNumber : String(3) not null;
  @sap.display.format : 'Date'
  @sap.label : 'de'
  @sap.quickinfo : 'Fecha válido de: En release actual sólo 00010101 posible'
  key ValidityStartDate : Date not null;
  @sap.label : 'Direc.por defecto'
  @sap.quickinfo : 'Ind.: Esta dirección es la dirección por defecto'
  key IsDefaultURLAddress : Boolean not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Dirección URI'
  @sap.quickinfo : 'Campo de búsqueda para la dirección URI'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  SearchURLAddress : String(50);
  @sap.label : 'Comentarios'
  @sap.quickinfo : 'Comentarios referentes al empalme de comunicación'
  AddressCommunicationRemarkText : String(50);
  @sap.label : 'Longitud URI'
  @sap.quickinfo : 'Longitud del campo URI'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  URLFieldLength : Integer;
  @sap.label : 'URI'
  @sap.quickinfo : 'Universal Resource Identifier (URI)'
  WebsiteURL : String(2048);
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Número de teléfono'
entity API_BUSINESS_PARTNER.A_AddressPhoneNumber {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº dirección'
  key AddressID : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Número de persona'
  key Person : String(10) not null;
  @sap.display.format : 'NonNegative'
  @sap.label : 'Número actual'
  key OrdinalNumber : String(3) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'País/Región'
  @sap.quickinfo : 'País/región para el número de teléfono/fax'
  DestinationLocationCountry : String(3);
  @sap.label : 'Nº estándar'
  @sap.quickinfo : 'Dirección remitente estándar en esta clase comunicación'
  IsDefaultPhoneNumber : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Teléfono'
  @sap.quickinfo : 'Número de teléfono: Prefijo y número'
  PhoneNumber : String(30);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Extensión'
  @sap.quickinfo : 'Número teléfono: Extensión'
  PhoneNumberExtension : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº teléfono'
  @sap.quickinfo : 'Número completo: Prefijo+línea+extensión'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  InternationalPhoneNumber : String(30);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Tel.móvil'
  @sap.quickinfo : 'Indicador: El teléfono es un teléfono móvil'
  PhoneNumberType : String(1);
  @sap.label : 'Comentarios'
  @sap.quickinfo : 'Comentarios referentes al empalme de comunicación'
  AddressCommunicationRemarkText : String(50);
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'ILN dependiente de dirección socio comercial'
entity API_BUSINESS_PARTNER.A_BPAddrDepdntIntlLocNumber {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Interloc.comercial'
  @sap.quickinfo : 'Número interlocutor comercial'
  key BusinessPartner : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº dirección'
  key AddressID : String(10) not null;
  @sap.display.format : 'NonNegative'
  @sap.label : 'Núm.ubicación int.1'
  @sap.quickinfo : 'International Location Number (parte 1)'
  InternationalLocationNumber1 : String(7);
  @sap.display.format : 'NonNegative'
  @sap.label : 'Núm.ubicación int.2'
  @sap.quickinfo : 'Número de ubicación internacional (parte 2)'
  InternationalLocationNumber2 : String(5);
  @sap.display.format : 'NonNegative'
  @sap.label : 'Dígito de control'
  @sap.quickinfo : 'Dígito de control para el Nº de empresa internacional'
  InternationalLocationNumber3 : String(1);
};

@cds.external : true
@cds.persistence.skip : true
@sap.deletable : 'false'
@sap.content.version : '1'
@sap.label : 'Dirección de persona de contacto'
entity API_BUSINESS_PARTNER.A_BPContactToAddress {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Número relación IC'
  @sap.quickinfo : 'Número de relación del interlocutor comercial'
  key RelationshipNumber : String(12) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Interloc.comercial'
  @sap.quickinfo : 'Número interlocutor comercial'
  key BusinessPartnerCompany : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Interloc.comercial'
  @sap.quickinfo : 'Número interlocutor comercial'
  key BusinessPartnerPerson : String(10) not null;
  @sap.display.format : 'Date'
  @sap.label : 'Fin de validez'
  @sap.quickinfo : 'Fecha de validez (válido a)'
  key ValidityEndDate : Date not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº dirección'
  key AddressID : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº dirección'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  AddressNumber : String(10);
  @sap.label : 'Calle 3'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  AdditionalStreetPrefixName : String(40);
  @sap.label : 'Calle 5'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  AdditionalStreetSuffixName : String(40);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Huso horario'
  @sap.quickinfo : 'Huso horario de la dirección'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  AddressTimeZone : String(6);
  @sap.label : 'c/o'
  @sap.quickinfo : 'Nombre c/o'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  CareOfName : String(40);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº de población'
  @sap.quickinfo : 'Codificación de población para fichero de población y calle'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  CityCode : String(12);
  @sap.label : 'Población'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  CityName : String(40);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cód.postal empresa'
  @sap.quickinfo : 'Código postal de la empresa (en caso de clientes import.)'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  CompanyPostalCode : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Clave de país/región'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  Country : String(3);
  @sap.label : 'Distrito'
  @sap.quickinfo : 'Distrito (US: County)'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  County : String(40);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Número serv.entrega'
  @sap.quickinfo : 'Número del servicio de entrega'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  DeliveryServiceNumber : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cl.serv.entrega'
  @sap.quickinfo : 'Clase del servicio de entrega'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  DeliveryServiceTypeCode : String(4);
  @sap.label : 'Distrito'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  District : String(40);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Tratamiento'
  @sap.quickinfo : 'Clave de tratamiento'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  FormOfAddress : String(4);
  @sap.label : 'Nombre completo'
  @sap.quickinfo : 'Nombre completo de parte (int.cial., un.org., direc.doc.)'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  FullName : String(80);
  @sap.label : 'Residencia alt.'
  @sap.quickinfo : 'Lugar de residencia (diferente de población cód.postal)'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  HomeCityName : String(40);
  @sap.label : 'Nº (edificio)'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  HouseNumber : String(10);
  @sap.label : 'Apéndice'
  @sap.quickinfo : 'Suplemento al número de casa'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  HouseNumberSupplementText : String(10);
  @sap.label : 'Clave de idioma'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  Language : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Apartado'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  POBox : String(10);
  @sap.label : 'Población apartado'
  @sap.quickinfo : 'Población del apartado'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  POBoxDeviatingCityName : String(40);
  @sap.display.format : 'UpperCase'
  @sap.label : 'País/reg.apartado'
  @sap.quickinfo : 'País/región de apartado de correos'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  POBoxDeviatingCountry : String(3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Región del apartado'
  @sap.quickinfo : 'Región del apartado (estado federal, land, provincia, etc.)'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  POBoxDeviatingRegion : String(3);
  @sap.label : 'Apartado sin nº'
  @sap.quickinfo : 'Indicador: Datos del apartado del correos sin número'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  POBoxIsWithoutNumber : Boolean;
  @sap.label : 'Estación ap.correos'
  @sap.quickinfo : 'Estación de apartado de correos (PO Box Lobby)'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  POBoxLobbyName : String(40);
  @sap.display.format : 'UpperCase'
  @sap.label : 'CP apartado'
  @sap.quickinfo : 'Código postal del apartado'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  POBoxPostalCode : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Número de persona'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  Person : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Código postal'
  @sap.quickinfo : 'Código postal de la población'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  PostalCode : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Forma comunicación'
  @sap.quickinfo : 'Forma de comunicación (clave) (Business Address Services)'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  PrfrdCommMediumType : String(3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Región'
  @sap.quickinfo : 'Región (Estado federal, Estado federado, provincia, condado)'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  Region : String(3);
  @sap.label : 'Calle'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  StreetName : String(60);
  @sap.label : 'Calle 2'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  StreetPrefixName : String(40);
  @sap.label : 'Calle 4'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  StreetSuffixName : String(40);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Domicilio fiscal'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  TaxJurisdiction : String(15);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Zona de transporte'
  @sap.quickinfo : 'Zona de transporte donde se efectúan las entregas'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  TransportZone : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Versión dirección'
  @sap.quickinfo : 'Indicadores de versión para direcciones internacionales'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  AddressRepresentationCode : String(1);
  @sap.label : 'Sigla del edificio'
  @sap.quickinfo : 'Edificio (número o sigla)'
  ContactPersonBuilding : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Forma comunicación'
  @sap.quickinfo : 'Forma de comunicación (clave) (Business Address Services)'
  ContactPersonPrfrdCommMedium : String(3);
  @sap.label : 'Departamento'
  ContactRelationshipDepartment : String(40);
  @sap.label : 'Función'
  ContactRelationshipFunction : String(40);
  @sap.label : 'Denominación breve'
  @sap.quickinfo : 'Denominación breve para correspondencia'
  CorrespondenceShortName : String(10);
  @sap.label : 'Piso'
  @sap.quickinfo : 'Planta del edificio'
  Floor : String(10);
  @sap.label : 'Correo interno'
  @sap.quickinfo : 'Código de correo interno'
  InhouseMail : String(10);
  @sap.label : 'Direc.estándar'
  @sap.quickinfo : 'Selección: Dirección es dirección estándar'
  IsDefaultAddress : Boolean;
  @sap.label : 'Número de sala'
  @sap.quickinfo : 'Número de un piso, un apartamento o una sala'
  RoomNumber : String(10);
  to_EmailAddress : Association to many API_BUSINESS_PARTNER.A_AddressEmailAddress {  };
  to_FaxNumber : Association to many API_BUSINESS_PARTNER.A_AddressFaxNumber {  };
  to_MobilePhoneNumber : Association to many API_BUSINESS_PARTNER.A_AddressPhoneNumber {  };
  to_PhoneNumber : Association to many API_BUSINESS_PARTNER.A_AddressPhoneNumber {  };
  to_URLAddress : Association to many API_BUSINESS_PARTNER.A_AddressHomePageURL {  };
};

@cds.external : true
@cds.persistence.skip : true
@sap.creatable : 'false'
@sap.deletable : 'false'
@sap.content.version : '1'
@sap.label : 'Cargo y departamento'
entity API_BUSINESS_PARTNER.A_BPContactToFuncAndDept {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Número relación IC'
  @sap.quickinfo : 'Número de relación del interlocutor comercial'
  key RelationshipNumber : String(12) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Interloc.comercial'
  @sap.quickinfo : 'Número interlocutor comercial'
  key BusinessPartnerCompany : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Interloc.comercial'
  @sap.quickinfo : 'Número interlocutor comercial'
  key BusinessPartnerPerson : String(10) not null;
  @sap.display.format : 'Date'
  @sap.label : 'Fin de validez'
  @sap.quickinfo : 'Fecha de validez (válido a)'
  key ValidityEndDate : Date not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Poder'
  @sap.quickinfo : 'Poder del interlocutor'
  ContactPersonAuthorityType : String(1);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Departamento'
  ContactPersonDepartment : String(4);
  @sap.label : 'Departamento empr.'
  @sap.quickinfo : 'Depto.en interlocutor comercial'
  ContactPersonDepartmentName : String(40);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Función'
  @sap.quickinfo : 'Función de interlocutor'
  ContactPersonFunction : String(4);
  @sap.label : 'Denominación función'
  @sap.quickinfo : 'Descripción de función de interlocutor EDI'
  ContactPersonFunctionName : String(40);
  @sap.label : 'Comentario'
  @sap.quickinfo : 'Comentarios acerca de un interlocutor'
  ContactPersonRemarkText : String(40);
  @sap.display.format : 'UpperCase'
  @sap.label : 'VIP'
  @sap.quickinfo : 'Interlocutor VIP'
  ContactPersonVIPType : String(1);
  @sap.label : 'Correo electrónico'
  @sap.quickinfo : 'Dirección de correo electrónico'
  EmailAddress : String(241);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Fax'
  @sap.quickinfo : 'Número de fax: Prefijo y número'
  FaxNumber : String(30);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Extensión'
  @sap.quickinfo : 'Nº fax: Extensión'
  FaxNumberExtension : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Teléfono'
  @sap.quickinfo : 'Número de teléfono: Prefijo y número'
  PhoneNumber : String(30);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Extensión'
  @sap.quickinfo : 'Número teléfono: Extensión'
  PhoneNumberExtension : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Tipo de relación'
  @sap.quickinfo : 'Tipo de relación de interlocutor comercial'
  RelationshipCategory : String(6);
};

@cds.external : true
@cds.persistence.skip : true
@sap.deletable : 'false'
@sap.content.version : '1'
@sap.label : 'Solvencia'
entity API_BUSINESS_PARTNER.A_BPCreditWorthiness {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Interm.financiero'
  @sap.quickinfo : 'Número de interlocutor comercial'
  key BusinessPartner : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Solvencia'
  BusPartCreditStanding : String(1);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Status inf.solvencia'
  @sap.quickinfo : 'Status de la información de solvencia'
  BPCreditStandingStatus : String(1);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Instituto solvencia'
  @sap.quickinfo : 'Instituto de información sobre la solvencia'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  CreditRatingAgency : String(4);
  @sap.label : 'Texto de solvencia'
  @sap.quickinfo : 'Otra información sobre solvencia'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  BPCreditStandingComment : String(50);
  @sap.display.format : 'Date'
  @sap.label : 'Fecha inf.solvencia'
  @sap.quickinfo : 'Fecha de la información sobre solvencia'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  BPCreditStandingDate : Date;
  @sap.label : 'Rating'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  BPCreditStandingRating : String(3);
  @sap.display.format : 'NonNegative'
  @sap.label : 'Estado del juicio'
  BPLegalProceedingStatus : String(2);
  @sap.display.format : 'Date'
  @sap.label : 'Fecha del juicio'
  @sap.quickinfo : 'Fecha de apertura del juicio'
  BPLglProceedingInitiationDate : Date;
  @sap.label : 'Decl.jur.estat.'
  @sap.quickinfo : 'Declaración jurada estatal'
  BusinessPartnerIsUnderOath : Boolean;
  @sap.display.format : 'Date'
  @sap.label : 'F.decl.jur.est.'
  @sap.quickinfo : 'Fecha de la declaración jurada estatal'
  BusinessPartnerOathDate : Date;
  @sap.label : 'ProcedInsolv'
  @sap.quickinfo : 'Procedimiento de insolvencia iniciado'
  BusinessPartnerIsBankrupt : Boolean;
  @sap.display.format : 'Date'
  @sap.label : 'FeProcInsolv'
  @sap.quickinfo : 'Fecha de inicio del proceso de insolvencia'
  BusinessPartnerBankruptcyDate : Date;
  @sap.label : 'Ejecución forzosa'
  BPForeclosureIsInitiated : Boolean;
  @sap.display.format : 'Date'
  @sap.label : 'Fecha ejecuc.forzosa'
  @sap.quickinfo : 'Fecha de la ejecución forzosa'
  BPForeclosureDate : Date;
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  BPCrdtWrthnssAccessChkIsActive : String(1);
};

@cds.external : true
@cds.persistence.skip : true
@sap.deletable : 'false'
@sap.content.version : '1'
@sap.label : 'Responsable del tratamiento del socio comercial'
entity API_BUSINESS_PARTNER.A_BPDataController {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Interloc.comercial'
  @sap.quickinfo : 'Número interlocutor comercial'
  key BusinessPartner : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Controlador datos'
  @sap.quickinfo : 'SC: Responsable del tratamiento'
  key DataController : String(30) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Objetivo'
  @sap.quickinfo : 'SC: Objetivo'
  key PurposeForPersonalData : String(30) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Est.asign.'
  @sap.quickinfo : 'SC: Estado asignación responsable/destino de utilización'
  DataControlAssignmentStatus : String(1);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Ind.deriv.CD'
  @sap.quickinfo : 'IC: Indicador de derivación para controlador de datos'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  BPDataControllerIsDerived : String(1);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Ind.deriv.fin'
  @sap.quickinfo : 'SC: Indicador de derivación para fin'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  PurposeDerived : String(1);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cl.dest.util.'
  @sap.quickinfo : 'SC: Clase de destino de utilización'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  PurposeType : String(1);
  @sap.display.format : 'UpperCase'
  @sap.label : 'DestUtiliz.cumpl.'
  @sap.quickinfo : 'Indicador de conclusión para objetivo de utilización'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  BusinessPurposeFlag : String(1);
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Resumen de ocupación'
entity API_BUSINESS_PARTNER.A_BPEmployment {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Interm.financiero'
  @sap.quickinfo : 'Número de interlocutor comercial'
  key BusinessPartner : String(10) not null;
  @sap.display.format : 'Date'
  @sap.label : 'Inicio de ocupación'
  key BPEmploymentStartDate : Date not null;
  @sap.display.format : 'Date'
  @sap.label : 'Fin de ocupación'
  BPEmploymentEndDate : Date;
  @sap.display.format : 'NonNegative'
  @sap.label : 'Status de ocupación'
  BPEmploymentStatus : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Sector'
  BusPartEmplrIndstryCode : String(10);
  @sap.label : 'Empresario'
  @sap.quickinfo : 'Nombre del empresario de una persona física'
  BusinessPartnerEmployerName : String(35);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Profesión'
  @sap.quickinfo : 'Profesión de interlocutor comercial'
  BusinessPartnerOccupationGroup : String(4);
};

@cds.external : true
@cds.persistence.skip : true
@sap.deletable : 'false'
@sap.content.version : '1'
@sap.label : 'Detalles de servicios financieros'
entity API_BUSINESS_PARTNER.A_BPFinancialServicesExtn {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Interloc.comercial'
  @sap.quickinfo : 'Número interlocutor comercial'
  key BusinessPartner : String(10) not null;
  @sap.label : 'Interloc.comerc.VIP'
  @sap.quickinfo : 'Interlocutor comercial es un VIP'
  BusinessPartnerIsVIP : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Sociedad GL asociada'
  @sap.quickinfo : 'Número de sociedad GL asociada'
  TradingPartner : String(6);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Calendario fábrica'
  @sap.quickinfo : 'Calendario de fábrica'
  FactoryCalendar : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'País/Reg.sede juríd.'
  @sap.quickinfo : 'País/Región de la sede jurídica'
  BusinessPartnerOfficeCountry : String(3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Región'
  @sap.quickinfo : 'Región de la sede jurídica'
  BusinessPartnerOfficeRegion : String(3);
  @sap.label : 'Sede jurídica'
  BPRegisteredOfficeName : String(35);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Moneda balance'
  @sap.quickinfo : 'Moneda del balance'
  @sap.semantics : 'currency-code'
  BPBalanceSheetCurrency : String(5);
  @sap.unit : 'BPBalanceSheetCurrency'
  @sap.label : 'Ampliación capital'
  @sap.quickinfo : 'Importe de la última ampliación de capital'
  BPLastCptlIncrAmtInBalShtCrcy : Decimal(16, 3);
  @sap.display.format : 'NonNegative'
  @sap.label : 'Ej.'
  @sap.quickinfo : 'Año de la última ampliación de capital'
  BPLastCapitalIncreaseYear : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Relac.balance'
  @sap.quickinfo : 'Relación del balance'
  BPBalanceSheetDisplayType : String(1);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nacionalidad'
  BusinessPartnerCitizenship : String(3);
  @sap.display.format : 'NonNegative'
  @sap.label : 'Rég.legí.bienes'
  @sap.quickinfo : 'Régimen legítimo de bienes'
  BPMaritalPropertyRegime : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Moneda'
  @sap.quickinfo : 'Moneda de los ingresos netos'
  @sap.semantics : 'currency-code'
  BusinessPartnerIncomeCurrency : String(5);
  @sap.label : 'Hijos'
  @sap.quickinfo : 'Cantidad de hijos del interlocutor comercial'
  BPNumberOfChildren : Decimal(2, 0);
  @sap.label : 'Miembros de familia'
  @sap.quickinfo : 'Número de miembros de la familia'
  BPNumberOfHouseholdMembers : Decimal(2, 0);
  @sap.unit : 'BusinessPartnerIncomeCurrency'
  @sap.label : 'Ingr.netos anuales'
  @sap.quickinfo : 'Ingr.anuales netos'
  BPAnnualNetIncAmtInIncomeCrcy : Decimal(16, 3);
  @sap.unit : 'BusinessPartnerIncomeCurrency'
  @sap.label : 'Ingresos netos mes'
  @sap.quickinfo : 'Ingresos netos mensuales del interlocutor comercial'
  BPMonthlyNetIncAmtInIncomeCrcy : Decimal(16, 3);
  @sap.display.format : 'NonNegative'
  @sap.label : 'Ej.'
  @sap.quickinfo : 'Año del ingreso neto anual obtenido'
  BPAnnualNetIncomeYear : String(4);
  @sap.display.format : 'NonNegative'
  @sap.label : 'Mes'
  @sap.quickinfo : 'Mes de los ingresos netos mensuales obtenidos'
  BPMonthlyNetIncomeMonth : String(2);
  @sap.display.format : 'NonNegative'
  @sap.label : 'Ejercicio'
  @sap.quickinfo : 'Ejercicio de los ingresos netos mensuales obtenidos'
  BPMonthlyNetIncomeYear : String(4);
  @sap.label : 'Lugar fallecimiento'
  @sap.quickinfo : 'Lugar de fallecimiento de una persona física'
  BPPlaceOfDeathName : String(40);
  @sap.label : 'Cliente no deseado'
  CustomerIsUnwanted : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Motivo no des.'
  @sap.quickinfo : 'Motivo de no deseado'
  UndesirabilityReason : String(2);
  @sap.label : 'Comentario'
  @sap.quickinfo : 'Comentario sobre no deseado'
  UndesirabilityComment : String(35);
  @sap.display.format : 'Date'
  @sap.label : 'Últ.fe.cont.clte.'
  @sap.quickinfo : 'Fecha del último contacto con cliente'
  LastCustomerContactDate : Date;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Caract.agrupación'
  @sap.quickinfo : 'Característica de agrupación'
  BPGroupingCharacter : String(10);
  @sap.display.format : 'NonNegative'
  @sap.label : 'Tratamiento'
  BPLetterSalutation : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo destino'
  BusinessPartnerTargetGroup : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo de personal'
  BusinessPartnerEmployeeGroup : String(4);
  @sap.label : 'Empleados'
  BusinessPartnerIsEmployee : Boolean;
  @sap.display.format : 'Date'
  @sap.label : 'Fecha final'
  @sap.quickinfo : 'Fecha de liquidación de relación comercial con banco'
  BPTermnBusRelationsBankDate : Date;
};

@cds.external : true
@cds.persistence.skip : true
@sap.deletable : 'false'
@sap.content.version : '1'
@sap.label : 'Informes de servicios financieros'
entity API_BUSINESS_PARTNER.A_BPFinancialServicesReporting {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Interm.financiero'
  @sap.quickinfo : 'Número de interlocutor comercial'
  key BusinessPartner : String(10) not null;
  @sap.label : 'No residente'
  @sap.quickinfo : 'No residente según artículo 4 de ley de comercio exterior'
  BPIsNonResident : Boolean;
  @sap.display.format : 'Date'
  @sap.label : 'No residente desde'
  @sap.quickinfo : 'Inicio no residencia según art.4 de ley de comercio exterior'
  BPNonResidencyStartDate : Date;
  @sap.label : 'Crédito millonario'
  @sap.quickinfo : 'Prestatario crédito millonario según §14 LOB'
  BPIsMultimillionLoanRecipient : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº prestatario'
  @sap.quickinfo : 'Número de prestatario p.visual.crédito según LOB'
  BPLoanReportingBorrowerNumber : String(8);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Núm.un.prestataria'
  @sap.quickinfo : 'Número de unidad prestataria p.visualizar crédito según LOB'
  BPLoanRptgBorrowerEntityNumber : String(8);
  @sap.display.format : 'NonNegative'
  @sap.label : 'Información LOB'
  @sap.quickinfo : 'Verificación de solvencia según art.18 de LOB'
  BPCreditStandingReview : String(2);
  @sap.display.format : 'Date'
  @sap.label : 'Fecha verific.LOB'
  @sap.quickinfo : 'Fecha de verificación de solvencia según art.18 LOB'
  BPCreditStandingReviewDate : Date;
  @sap.display.format : 'NonNegative'
  @sap.label : 'Crédito a directivos'
  @sap.quickinfo : 'Crédito a directivos según § 15 LOB'
  BusinessPartnerLoanToManager : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Relación empr.'
  @sap.quickinfo : 'Relación empresarial'
  BPCompanyRelationship : String(1);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº prestamista'
  @sap.quickinfo : 'Nº prestamista para visualización crédito por KWG'
  BPLoanReportingCreditorNumber : String(8);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº identif.BNA'
  @sap.quickinfo : 'Número de identificación (BNA)'
  BPOeNBIdentNumber : String(11);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Gpo.destino BNA'
  @sap.quickinfo : 'Grupo destino según BNA'
  BPOeNBTargetGroup : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Adjudicar nº ident.'
  @sap.quickinfo : 'Adjudicar número identificación (BNA)'
  BPOeNBIdentNumberAssigned : String(1);
  @sap.display.format : 'UpperCase'
  @sap.label : 'CII BNA'
  @sap.quickinfo : 'código de identificación de la institución según BNA'
  BPOeNBInstituteNumber : String(7);
  @sap.label : 'InstSujDeclBNA'
  @sap.quickinfo : 'Instituto sujeto a declaración según BNA'
  BusinessPartnerIsOeNBInstitute : Boolean;
  @sap.label : 'Nº identif.gpo.'
  @sap.quickinfo : 'Núm.identif.gpo.'
  BusinessPartnerGroup : String(15);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Tipo de asignación de grupo'
  BPGroupAssignmentCategory : String(1);
  @sap.label : 'Denominación grupo'
  @sap.quickinfo : 'Denominación del grupo'
  BusinessPartnerGroupName : String(50);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Persona jurídica'
  @sap.quickinfo : 'Persona jurídica del interlocutor comercial'
  BusinessPartnerLegalEntity : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Art.4 pto.2 Regl.AF'
  @sap.quickinfo : 'Interlocutor comercial según el artículo 4, punto 2 Regl.AF'
  BPGerAstRglnRestrictedAstQuota : String(1);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo de deudores'
  @sap.quickinfo : 'Grupo deudores según normativa reporting cias.aseg.modelo 5'
  BusinessPartnerDebtorGroup : String(1);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Objetivo empresarial'
  @sap.quickinfo : 'Tipo de objetivo empresarial'
  BusinessPartnerBusinessPurpose : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Clase de riesgo'
  BusinessPartnerRiskGroup : String(1);
  @sap.display.format : 'Date'
  @sap.label : 'Fe.inic.agrup.'
  @sap.quickinfo : 'Fecha de la agrupación de riesgos'
  BPRiskGroupingDate : Date;
  @sap.label : 'Perten.gpo.empresas'
  @sap.quickinfo : 'Existe pertenencia a un grupo de empresas'
  BPHasGroupAffiliation : Boolean;
  @sap.label : 'Instit.financ.mon.'
  @sap.quickinfo : 'Institución financiera monetaria'
  BPIsMonetaryFinInstitution : Boolean;
  @sap.label : 'Relev.p.solv.§18'
  @sap.quickinfo : 'Entr.obligatoria p.verificación solvencia según § 18 LOB'
  BPCrdtStandingReviewIsRequired : Boolean;
  @sap.label : 'CtrlGrandesCréditos'
  @sap.quickinfo : 'Indicador control de grandes créditos según art.13b LOB'
  BPLoanMonitoringIsRequired : Boolean;
  @sap.label : 'Red.impte.imputable'
  @sap.quickinfo : 'Reducción importe imputable según art.13/3 LOB'
  BPHasCreditingRelief : Boolean;
  @sap.label : 'Art.2 p.1 nº18b RgAF'
  @sap.quickinfo : 'Autorizado según art.2 punto 1 nº 18b Regl.AF'
  BPInvestInRstrcdAstIsAuthzd : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Ind.país/región BCR'
  @sap.quickinfo : 'Código numérico del indicador de país/región del BCR'
  BPCentralBankCountryRegion : String(4);
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Información sobre el ejercicio'
entity API_BUSINESS_PARTNER.A_BPFiscalYearInformation {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Interm.financiero'
  @sap.quickinfo : 'Número de interlocutor comercial'
  key BusinessPartner : String(10) not null;
  @sap.display.format : 'NonNegative'
  @sap.label : 'Ejercicio'
  key BusinessPartnerFiscalYear : String(4) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Moneda balance'
  @sap.quickinfo : 'Moneda del balance'
  @sap.semantics : 'currency-code'
  BPBalanceSheetCurrency : String(5);
  @sap.display.format : 'Date'
  @sap.label : 'Junta general'
  @sap.quickinfo : 'Fecha de la junta general'
  BPAnnualStockholderMeetingDate : Date;
  @sap.display.format : 'Date'
  @sap.label : 'Inicio ejercicio'
  @sap.quickinfo : 'Fecha de inicio del ejercicio'
  BPFiscalYearStartDate : Date;
  @sap.display.format : 'Date'
  @sap.label : 'Fin del ejercicio'
  @sap.quickinfo : 'Fecha de fin del ejercicio'
  BPFiscalYearEndDate : Date;
  @sap.label : 'Cierre del ejercicio'
  BPFiscalYearIsClosed : Boolean;
  @sap.display.format : 'Date'
  @sap.label : 'Cierre del ejercicio'
  @sap.quickinfo : 'Fecha del cierre anual del ejercicio'
  BPFiscalYearClosingDate : Date;
  @sap.display.format : 'Date'
  @sap.label : 'Estado consolidado'
  @sap.quickinfo : 'Fecha del estado consolidado actual de sociedades GL'
  BPFsclYrCnsldtdFinStatementDte : Date;
  @sap.unit : 'BPBalanceSheetCurrency'
  @sap.label : 'Capital social'
  @sap.quickinfo : 'Importe del capital social autorizado de la empresa'
  BPCapitalStockAmtInBalShtCrcy : Decimal(16, 3);
  @sap.unit : 'BPBalanceSheetCurrency'
  @sap.label : 'Capital social emit.'
  @sap.quickinfo : 'Importe del capital social emitido de la empresa'
  BPIssdStockCptlAmtInBalShtCrcy : Decimal(16, 3);
  @sap.unit : 'BPBalanceSheetCurrency'
  @sap.label : 'Capital de disfrute'
  @sap.quickinfo : 'Importe del capital de disfrute de la empresa'
  BPPartcipnCertAmtInBalShtCrcy : Decimal(16, 3);
  @sap.unit : 'BPBalanceSheetCurrency'
  @sap.label : 'Recursos prop.'
  @sap.quickinfo : 'Importe de los recursos propios de la empresa'
  BPEquityCapitalAmtInBalShtCrcy : Decimal(16, 3);
  @sap.unit : 'BPBalanceSheetCurrency'
  @sap.label : 'Contrib.bruta'
  @sap.quickinfo : 'Contribución bruta'
  BPGrossPremiumAmtInBalShtCrcy : Decimal(16, 3);
  @sap.unit : 'BPBalanceSheetCurrency'
  @sap.label : 'Contrib.neta'
  @sap.quickinfo : 'Contribución neta'
  BPNetPremiumAmtInBalShtCrcy : Decimal(16, 3);
  @sap.unit : 'BPBalanceSheetCurrency'
  @sap.label : 'Vol.neg.anual'
  @sap.quickinfo : 'Importe del volumen de negocios anual de la empresa'
  BPAnnualSalesAmtInBalShtCrcy : Decimal(16, 3);
  @sap.unit : 'BPBalanceSheetCurrency'
  @sap.label : 'Superávit ejer.'
  @sap.quickinfo : 'Importe del superávit/déficit anual de la empresa'
  BPAnnualNetIncAmtInBalShtCrcy : Decimal(16, 3);
  @sap.unit : 'BPBalanceSheetCurrency'
  @sap.label : 'Dividendos'
  @sap.quickinfo : 'Dividendos/Importe de reparto de la empresa'
  BPDividendDistrAmtInBalShtCrcy : Decimal(16, 3);
  @sap.label : 'Factor endeudamiento'
  @sap.quickinfo : 'Factor de endeudamiento en años'
  BPDebtRatioInYears : Decimal(6, 3);
  @sap.unit : 'BPBalanceSheetCurrency'
  @sap.label : 'Beneficio registrado'
  @sap.quickinfo : 'Importe de beneficio/pérdida anual de la empresa'
  BPAnnualPnLAmtInBalShtCrcy : Decimal(16, 3);
  @sap.unit : 'BPBalanceSheetCurrency'
  @sap.label : 'Total balance'
  @sap.quickinfo : 'Importe del total de balance de la empresa'
  BPBalSheetTotalAmtInBalShtCrcy : Decimal(16, 3);
  @sap.display.format : 'NonNegative'
  @sap.label : 'Cantidad empleados'
  @sap.quickinfo : 'Cantidad de empleados de la empresa'
  BPNumberOfEmployees : String(7);
  @sap.unit : 'BPBalanceSheetCurrency'
  @sap.label : 'Reserva cap.'
  @sap.quickinfo : 'Importe de la reserva de capital de la empresa'
  BPCptlReserveAmtInBalShtCrcy : Decimal(16, 3);
  @sap.unit : 'BPBalanceSheetCurrency'
  @sap.label : 'Reserva restr.legal'
  @sap.quickinfo : 'Importe de la reserva restringida legal de la empresa'
  BPLglRevnRsrvAmtInBalShtCrcy : Decimal(16, 3);
  @sap.unit : 'BPBalanceSheetCurrency'
  @sap.label : 'ResRestPartProp'
  @sap.quickinfo : 'Reserva restringinda para participaciones propias'
  RevnRsrvOwnStkAmtInBalShtCrcy : Decimal(16, 3);
  @sap.unit : 'BPBalanceSheetCurrency'
  @sap.label : 'Reservas restr.est.'
  @sap.quickinfo : 'Importe de reservas restringidas estatutarias de la empresa'
  BPStatryReserveAmtInBalShtCrcy : Decimal(16, 3);
  @sap.unit : 'BPBalanceSheetCurrency'
  @sap.label : 'Otras res.restr.'
  @sap.quickinfo : 'Importe de las otras reservas restringidas de la empresa'
  BPOthRevnRsrvAmtInBalShtCrcy : Decimal(16, 3);
  @sap.unit : 'BPBalanceSheetCurrency'
  @sap.label : 'Arrastre ben./pérd.'
  @sap.quickinfo : 'Importe de arrastre de beneficios y pérdidas de la empresa'
  BPPnLCarryfwdAmtInBalShtCrcy : Decimal(16, 3);
  @sap.unit : 'BPBalanceSheetCurrency'
  @sap.label : 'Deud.subordinadas'
  @sap.quickinfo : 'Importe de las deudas subordinadas de la empresa'
  BPSuborddLbltyAmtInBalShtCrcy : Decimal(16, 3);
  @sap.label : 'RendimCapTotal'
  @sap.quickinfo : 'Rendimiento del capital total de la empresa en porcentaje'
  BPRetOnTotalCptlEmpldInPercent : Decimal(5, 2);
  @sap.label : 'Dur.liquid.deudas'
  @sap.quickinfo : 'Duración de la liquidación de deudas en años'
  BPDebtClearancePeriodInYears : Decimal(5, 2);
  @sap.label : 'Coef.financiero'
  @sap.quickinfo : 'Coeficiente de financiación de la empresa en porcentaje'
  BPFinancingCoeffInPercent : Decimal(5, 2);
  @sap.label : 'Cuota cap.prop.'
  @sap.quickinfo : 'Cuota de capital propio de la empresa en porcentaje'
  BPEquityRatioInPercent : Decimal(5, 2);
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Versión de dirección internacional de IC'
entity API_BUSINESS_PARTNER.A_BPIntlAddressVersion {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Interloc.comercial'
  @sap.quickinfo : 'Número interlocutor comercial'
  key BusinessPartner : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº dirección'
  key AddressID : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Versión dirección'
  @sap.quickinfo : 'Indicadores de versión para direcciones internacionales'
  key AddressRepresentationCode : String(1) not null;
  @sap.label : 'Nombre completo'
  @sap.quickinfo : 'Nombre completo de la persona'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  AddresseeFullName : String(80);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Número direc.externo'
  @sap.quickinfo : 'Número de dirección en sistema externo'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  AddressIDByExternalSystem : String(20);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Número de persona'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  AddressPersonID : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Concepto búsqueda 1'
  @sap.quickinfo : 'Concepto de búsqueda 1'
  AddressSearchTerm1 : String(20);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Concepto búsqueda 2'
  @sap.quickinfo : 'Concepto de búsqueda 2'
  AddressSearchTerm2 : String(20);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Huso horario'
  @sap.quickinfo : 'Huso horario de la dirección'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  AddressTimeZone : String(6);
  @sap.label : 'c/o'
  @sap.quickinfo : 'Nombre c/o'
  CareOfName : String(40);
  @sap.label : 'Población'
  CityName : String(40);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº de población'
  @sap.quickinfo : 'Codificación de población para fichero de población y calle'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  CityNumber : String(12);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cód.postal empresa'
  @sap.quickinfo : 'Código postal de la empresa (en caso de clientes import.)'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  CompanyPostalCode : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Clave de país/región'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  Country : String(3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Número serv.entrega'
  @sap.quickinfo : 'Número del servicio de entrega'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  DeliveryServiceNumber : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cl.serv.entrega'
  @sap.quickinfo : 'Clase del servicio de entrega'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  DeliveryServiceTypeCode : String(4);
  @sap.label : 'Distrito'
  DistrictName : String(40);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Tratamiento'
  @sap.quickinfo : 'Clave de tratamiento'
  FormOfAddress : String(4);
  @sap.label : 'Nº (edificio)'
  HouseNumber : String(10);
  @sap.label : 'Apéndice'
  @sap.quickinfo : 'Suplemento al número de casa'
  HouseNumberSupplementText : String(10);
  @sap.label : 'Clave de idioma'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  Language : String(2);
  @sap.label : 'Nombre'
  @sap.quickinfo : 'Nombre 1'
  OrganizationName1 : String(40);
  @sap.label : 'Nombre 2'
  OrganizationName2 : String(40);
  @sap.label : 'Nombre 3'
  OrganizationName3 : String(40);
  @sap.label : 'Nombre 4'
  OrganizationName4 : String(40);
  @sap.label : 'Apellido'
  PersonFamilyName : String(40);
  @sap.label : 'Nombre'
  PersonGivenName : String(40);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Apartado'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  POBox : String(10);
  @sap.label : 'Población apartado'
  @sap.quickinfo : 'Población del apartado'
  POBoxDeviatingCityName : String(40);
  @sap.display.format : 'UpperCase'
  @sap.label : 'País/reg.apartado'
  @sap.quickinfo : 'País/región de apartado de correos'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  POBoxDeviatingCountry : String(3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Región del apartado'
  @sap.quickinfo : 'Región del apartado (estado federal, land, provincia, etc.)'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  POBoxDeviatingRegion : String(3);
  @sap.label : 'Apartado sin nº'
  @sap.quickinfo : 'Indicador: Datos del apartado del correos sin número'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  POBoxIsWithoutNumber : Boolean;
  @sap.label : 'Estación ap.correos'
  @sap.quickinfo : 'Estación de apartado de correos (PO Box Lobby)'
  POBoxLobbyName : String(40);
  @sap.display.format : 'UpperCase'
  @sap.label : 'CP apartado'
  @sap.quickinfo : 'Código postal del apartado'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  POBoxPostalCode : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Código postal'
  @sap.quickinfo : 'Código postal de la población'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  PostalCode : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Forma comunicación'
  @sap.quickinfo : 'Forma de comunicación (clave) (Business Address Services)'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  PrfrdCommMediumType : String(3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Región'
  @sap.quickinfo : 'Región (Estado federal, Estado federado, provincia, condado)'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  Region : String(3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cód.ár.cir.'
  @sap.quickinfo : 'Código de área circular para área circular'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  SecondaryRegion : String(8);
  @sap.label : 'Distrito'
  @sap.quickinfo : 'Distrito (US: County)'
  SecondaryRegionName : String(40);
  @sap.label : 'Calle'
  StreetName : String(60);
  @sap.label : 'Calle 2'
  StreetPrefixName1 : String(40);
  @sap.label : 'Calle 3'
  StreetPrefixName2 : String(40);
  @sap.label : 'Calle 4'
  StreetSuffixName1 : String(40);
  @sap.label : 'Calle 5'
  StreetSuffixName2 : String(40);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Domicilio fiscal'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  TaxJurisdiction : String(15);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Código ciudad'
  @sap.quickinfo : 'Código de ciudad para ciudad'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  TertiaryRegion : String(8);
  @sap.label : 'Ciudad'
  TertiaryRegionName : String(40);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Zona de transporte'
  @sap.quickinfo : 'Zona de transporte donde se efectúan las entregas'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  TransportZone : String(10);
  @sap.label : 'Residencia alt.'
  @sap.quickinfo : 'Lugar de residencia (diferente de población cód.postal)'
  VillageName : String(40);
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Relación entre socios comerciales'
entity API_BUSINESS_PARTNER.A_BPRelationship {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Número relación IC'
  @sap.quickinfo : 'Número de relación del interlocutor comercial'
  key RelationshipNumber : String(12) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Interloc.comercial'
  @sap.quickinfo : 'Número interlocutor comercial'
  key BusinessPartner1 : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Interloc.comercial'
  @sap.quickinfo : 'Número interlocutor comercial'
  key BusinessPartner2 : String(10) not null;
  @sap.display.format : 'Date'
  @sap.label : 'Fin de validez'
  @sap.quickinfo : 'Fecha de validez (válido a)'
  key ValidityEndDate : Date not null;
  @sap.display.format : 'Date'
  @sap.label : 'Inicio validez'
  @sap.quickinfo : 'Fecha de validez (válido de)'
  ValidityStartDate : Date;
  @sap.label : 'Estándar'
  @sap.quickinfo : 'Relación estándar'
  IsStandardRelationship : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Tipo de relación'
  @sap.quickinfo : 'Tipo de relación de interlocutor comercial'
  RelationshipCategory : String(6);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Clase de relación'
  @sap.quickinfo : 'Clase relación interlocutor comercial'
  BPRelationshipType : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Creado por'
  @sap.quickinfo : 'Usuario que ha creado el objeto'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  CreatedByUser : String(12);
  @sap.display.format : 'Date'
  @sap.label : 'Creado el'
  @sap.quickinfo : 'Fecha de creación de objeto'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  CreationDate : Date;
  @sap.label : 'Creado a las'
  @sap.quickinfo : 'Hora de creación de objeto'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  CreationTime : Time;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Modificado por'
  @sap.quickinfo : 'Último usuario en modificar el objeto'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  LastChangedByUser : String(12);
  @sap.display.format : 'Date'
  @sap.label : 'Modificado el'
  @sap.quickinfo : 'Fecha de última modificación del objeto'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  LastChangeDate : Date;
  @sap.label : 'Modificado a las'
  @sap.quickinfo : 'Hora de última modificación del objeto'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  LastChangeTime : Time;
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Cumplimiento de obligaciones tributarias'
entity API_BUSINESS_PARTNER.A_BPTaxCompliance {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Interloc.comercial'
  @sap.quickinfo : 'Número interlocutor comercial'
  key BusinessPartner : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'ID'
  @sap.quickinfo : 'ID de reporting fiscal'
  key BPTaxComplianceID : String(6) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Tipo'
  @sap.quickinfo : 'Tipo de reporting fiscal'
  BPTaxComplianceType : String(6);
  @sap.display.format : 'UpperCase'
  @sap.label : 'País/Región'
  @sap.quickinfo : 'Cumplimiento de obligaciones tributarias: País/Región'
  BPTaxComplianceCountryRegion : String(3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Región'
  @sap.quickinfo : 'Reporting fiscal: Región'
  BPTaxComplianceRegion : String(3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Status'
  @sap.quickinfo : 'Status de reporting fiscal'
  BPTaxComplianceStatus : String(1);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Motivo'
  @sap.quickinfo : 'Reporting fiscal: Justificación del status'
  BPTaxComplianceStatusReason : String(2);
  @sap.display.format : 'Date'
  @sap.label : 'Válido de'
  @sap.quickinfo : 'Reporting fiscal: Fecha de inicio'
  BPTaxComplianceValidFromDate : Date;
  @sap.display.format : 'Date'
  @sap.label : 'Validez a'
  @sap.quickinfo : 'Reporting fiscal: Fecha de fin'
  BPTaxComplianceValidToDate : Date;
  @sap.display.format : 'Date'
  @sap.label : 'Fecha de valoración'
  @sap.quickinfo : 'Reporting fiscal: Fecha de valoración'
  BPTaxComplianceRatingDate : Date;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Aceptación'
  @sap.quickinfo : 'Reporting fiscal: Status de aceptación'
  BPTaxComplianceAgreementStatus : String(1);
  @sap.display.format : 'Date'
  @sap.label : 'Fecha de aceptación'
  @sap.quickinfo : 'Reporting fiscal: Fecha de aceptación'
  BPTaxComplianceAgreementDate : Date;
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Utilización de dirección'
entity API_BUSINESS_PARTNER.A_BuPaAddressUsage {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Interloc.comercial'
  @sap.quickinfo : 'Número interlocutor comercial'
  key BusinessPartner : String(10) not null;
  @odata.Type : 'Edm.DateTimeOffset'
  @sap.label : 'Fin de validez'
  @sap.quickinfo : 'Fin de validez de utilización de dirección interl.comercial'
  key ValidityEndDate : DateTime not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cl.direc.'
  key AddressUsage : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº dirección'
  key AddressID : String(10) not null;
  @odata.Type : 'Edm.DateTimeOffset'
  @sap.label : 'Inicio validez'
  @sap.quickinfo : 'Inicio validez de utilización de dirección interl.comercial'
  ValidityStartDate : DateTime;
  @sap.label : 'Utiliz.estándar'
  @sap.quickinfo : 'Indicador: Dirección estándar de utilización de dirección'
  StandardUsage : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo autorizaciones'
  @sap.quickinfo : 'Grupo de autorizaciones'
  AuthorizationGroup : String(4);
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Identificación'
entity API_BUSINESS_PARTNER.A_BuPaIdentification {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Interloc.comercial'
  @sap.quickinfo : 'Número interlocutor comercial'
  key BusinessPartner : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Clase identificación'
  @sap.quickinfo : 'Clase de identificación'
  key BPIdentificationType : String(6) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº identificación'
  @sap.quickinfo : 'Número de identificación'
  key BPIdentificationNumber : String(60) not null;
  @sap.label : 'Institución respons.'
  @sap.quickinfo : 'Institución responsable del número de identificación'
  BPIdnNmbrIssuingInstitute : String(40);
  @sap.display.format : 'Date'
  @sap.label : 'Fecha de entrada'
  @sap.quickinfo : 'Fecha de entrada para el número de identificación'
  BPIdentificationEntryDate : Date;
  @sap.display.format : 'UpperCase'
  @sap.label : 'País/Región'
  @sap.quickinfo : 'País/región en que es válido o al/la que se ha adj.número ID'
  Country : String(3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Región'
  @sap.quickinfo : 'Región (Estado federal, Estado federado, provincia, condado)'
  Region : String(3);
  @sap.display.format : 'Date'
  @sap.label : 'Válido de'
  @sap.quickinfo : 'Inicio de la validez del número de identificación'
  ValidityStartDate : Date;
  @sap.display.format : 'Date'
  @sap.label : 'Fin de validez'
  @sap.quickinfo : 'Fin de la validez del número de identificación'
  ValidityEndDate : Date;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo autorizaciones'
  @sap.quickinfo : 'Grupo de autorizaciones'
  AuthorizationGroup : String(4);
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Especialidad'
entity API_BUSINESS_PARTNER.A_BuPaIndustry {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Sector'
  key IndustrySector : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'SistSectIndust'
  @sap.quickinfo : 'Sistema sector industrial'
  key IndustrySystemType : String(4) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Interloc.comercial'
  @sap.quickinfo : 'Número interlocutor comercial'
  key BusinessPartner : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Ramo industrial std.'
  @sap.quickinfo : 'Es ramo industrial estándar en sistema sectores industriales'
  IsStandardIndustry : String(1);
  @sap.label : 'Denominación'
  IndustryKeyDescription : String(100);
};

@cds.external : true
@cds.persistence.skip : true
@sap.deletable : 'false'
@sap.content.version : '1'
@sap.label : 'Interlocutor cial.'
entity API_BUSINESS_PARTNER.A_BusinessPartner {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Interloc.comercial'
  @sap.quickinfo : 'Número interlocutor comercial'
  key BusinessPartner : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cliente'
  @sap.quickinfo : 'Número de cliente'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  Customer : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Proveedor'
  @sap.quickinfo : 'Número de cuenta del proveedor o acreedor'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  Supplier : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Título académico 1'
  @sap.quickinfo : 'Título académico: Clave'
  AcademicTitle : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo autorizaciones'
  @sap.quickinfo : 'Grupo de autorizaciones'
  AuthorizationGroup : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Tipo socio comercial'
  @sap.quickinfo : 'Tipo de socio comercial'
  BusinessPartnerCategory : String(1);
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  BusinessPartnerFullName : String(81);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Agrupación'
  @sap.quickinfo : 'Agrupación interlocutores comerciales'
  BusinessPartnerGrouping : String(4);
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  BusinessPartnerName : String(81);
  @sap.label : 'ID único IC'
  @sap.quickinfo : 'UID de interlocutor comercial'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  BusinessPartnerUUID : UUID;
  @sap.label : 'Idi.correspondencia'
  @sap.quickinfo : 'Interlocutor comercial: Idioma de correspondencia'
  CorrespondenceLanguage : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Creado por'
  @sap.quickinfo : 'Usuario que ha creado el objeto'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  CreatedByUser : String(12);
  @sap.display.format : 'Date'
  @sap.label : 'Creado el'
  @sap.quickinfo : 'Fecha de creación de objeto'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  CreationDate : Date;
  @sap.label : 'Creado a las'
  @sap.quickinfo : 'Hora de creación de objeto'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  CreationTime : Time;
  @sap.label : 'Nombre'
  @sap.quickinfo : 'Nombre de pila de socio comercial (persona)'
  FirstName : String(40);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Tratamiento'
  @sap.quickinfo : 'Clave de tratamiento'
  FormOfAddress : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Ramo'
  Industry : String(10);
  @sap.display.format : 'NonNegative'
  @sap.label : 'Núm.ubicación int.1'
  @sap.quickinfo : 'International Location Number (parte 1)'
  InternationalLocationNumber1 : String(7);
  @sap.display.format : 'NonNegative'
  @sap.label : 'Núm.ubicación int.2'
  @sap.quickinfo : 'Número de ubicación internacional (parte 2)'
  InternationalLocationNumber2 : String(5);
  @sap.label : 'Femenino'
  @sap.quickinfo : 'Selección: Interlocutor comercial es femenino'
  IsFemale : Boolean;
  @sap.label : 'Masculino'
  @sap.quickinfo : 'Selección: Interlocutor comercial es masculino'
  IsMale : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Persona física'
  @sap.quickinfo : 'El interlocutor comercial sirve como persona física fiscal'
  IsNaturalPerson : String(1);
  @sap.label : 'Desconocido'
  @sap.quickinfo : 'Selección: Sexo del interlocutor comercial desconocido'
  IsSexUnknown : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Sexo'
  @sap.quickinfo : 'Sexo del interlocutor comercial (persona)'
  GenderCodeName : String(1);
  @sap.label : 'Idioma'
  @sap.quickinfo : 'Interloc.comercial: Idioma'
  Language : String(2);
  @sap.display.format : 'Date'
  @sap.label : 'Modificado el'
  @sap.quickinfo : 'Fecha de última modificación del objeto'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  LastChangeDate : Date;
  @sap.label : 'Modificado a las'
  @sap.quickinfo : 'Hora de última modificación del objeto'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  LastChangeTime : Time;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Modificado por'
  @sap.quickinfo : 'Último usuario en modificar el objeto'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  LastChangedByUser : String(12);
  @sap.label : 'Apellidos'
  @sap.quickinfo : 'Apellidos de socio comercial (persona)'
  LastName : String(40);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Forma jurídica'
  @sap.quickinfo : 'IC: Forma jurídica de organización'
  LegalForm : String(2);
  @sap.label : 'Nombre 1'
  @sap.quickinfo : 'Nombre 1 de organización'
  OrganizationBPName1 : String(40);
  @sap.label : 'Nombre 2'
  @sap.quickinfo : 'Nombre 2 de organización'
  OrganizationBPName2 : String(40);
  @sap.label : 'Nombre 3'
  @sap.quickinfo : 'Nombre 3 de organización'
  OrganizationBPName3 : String(40);
  @sap.label : 'Nombre 4'
  @sap.quickinfo : 'Nombre 4 de organización'
  OrganizationBPName4 : String(40);
  @sap.display.format : 'Date'
  @sap.label : 'Fecha fundación'
  @sap.quickinfo : 'Fecha fundación de organización'
  OrganizationFoundationDate : Date;
  @sap.display.format : 'Date'
  @sap.label : 'Fecha liquidación'
  @sap.quickinfo : 'Fecha liquidación de organización'
  OrganizationLiquidationDate : Date;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Concepto búsqueda 1'
  @sap.quickinfo : 'Concepto de búsqueda 1 relativo al interlocutor comercial'
  SearchTerm1 : String(20);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Concepto búsqueda 2'
  @sap.quickinfo : 'Concepto de búsqueda 2 relativo al interlocutor comercial'
  SearchTerm2 : String(20);
  @sap.label : '2º apellido'
  @sap.quickinfo : 'Segundo apellido de persona'
  AdditionalLastName : String(40);
  @sap.display.format : 'Date'
  @sap.label : 'Fecha de nacimiento'
  @sap.quickinfo : 'Fecha de nacimiento del socio comercial'
  BirthDate : Date;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Status fecha nacim.'
  @sap.quickinfo : 'Fecha de nacimiento: Status'
  BusinessPartnerBirthDateStatus : String(1);
  @sap.label : 'Lugar de nacimiento'
  @sap.quickinfo : 'Lugar de nacimiento de interlocutor comercial'
  BusinessPartnerBirthplaceName : String(40);
  @sap.display.format : 'Date'
  @sap.label : 'Fecha fallecimiento'
  @sap.quickinfo : 'Fecha de fallecimiento de interlocutor comercial'
  BusinessPartnerDeathDate : Date;
  @sap.label : 'Bloqueo central'
  @sap.quickinfo : 'Bloqueo central para el socio comercial'
  BusinessPartnerIsBlocked : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cl.interlocutor com.'
  @sap.quickinfo : 'Clase de interlocutor comercial'
  BusinessPartnerType : String(4);
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  ETag : String(26);
  @sap.label : 'Nombre 1'
  @sap.quickinfo : 'Nombre 1 (grupo)'
  GroupBusinessPartnerName1 : String(40);
  @sap.label : 'Nombre 2'
  @sap.quickinfo : 'Nombre 2 (grupo)'
  GroupBusinessPartnerName2 : String(40);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº dirección'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  IndependentAddressID : String(10);
  @sap.display.format : 'NonNegative'
  @sap.label : 'Dígito de control'
  @sap.quickinfo : 'Dígito de control para el Nº de empresa internacional'
  InternationalLocationNumber3 : String(1);
  @sap.label : '2º nombre'
  @sap.quickinfo : 'Segundo nombre de la persona'
  MiddleName : String(40);
  @sap.display.format : 'UpperCase'
  @sap.label : 'País/región edición'
  @sap.quickinfo : 'País/región para regla de edición del nombre'
  NameCountry : String(3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Formato edición nom.'
  @sap.quickinfo : 'Formato para la edición del nombre'
  NameFormat : String(2);
  @sap.label : 'Nombre completo'
  PersonFullName : String(80);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Número de persona'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  PersonNumber : String(10);
  @sap.label : 'Petición archivo'
  @sap.quickinfo : 'Petición central de archivo'
  IsMarkedForArchiving : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'N.º socio.com.ext.'
  @sap.quickinfo : 'Número de socio comercial en sistema externo'
  BusinessPartnerIDByExtSystem : String(20);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Formato de impresión'
  @sap.quickinfo : 'Formato impresión interlocutor comercial'
  BusinessPartnerPrintFormat : String(1);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Profesión'
  @sap.quickinfo : 'Profesión de interlocutor comercial'
  BusinessPartnerOccupation : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Estado civil'
  @sap.quickinfo : 'Estado civil de interlocutor comercial'
  BusPartMaritalStatus : String(1);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nacionalidad'
  @sap.quickinfo : 'Nacionalidad de interlocutor comercial'
  BusPartNationality : String(3);
  @sap.label : 'Apellido de soltera'
  @sap.quickinfo : 'Apellido de soltera de interlocutor comercial'
  BusinessPartnerBirthName : String(40);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Complemento nombre'
  @sap.quickinfo : 'Complemento del nombre, p.ej.título nobiliario (clave)'
  BusinessPartnerSupplementName : String(4);
  @sap.label : 'Empresario'
  @sap.quickinfo : 'Nombre del empresario de una persona física'
  NaturalPersonEmployerName : String(35);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Clave prefijo'
  @sap.quickinfo : 'Prefijo del nombre (clave)'
  LastNamePrefix : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : '2º prefijo'
  @sap.quickinfo : '2º prefijo del nombre (clave)'
  LastNameSecondPrefix : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Iniciales'
  @sap.quickinfo : 'Inicial del segundo nombre o iniciales de la persona'
  Initials : String(10);
  @sap.label : 'PR no es necrsario'
  @sap.quickinfo : 'SC: Puesto responsable no es necesario'
  BPDataControllerIsNotRequired : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Sociedad GL asociada'
  @sap.quickinfo : 'Número de sociedad GL asociada'
  TradingPartner : String(6);
  to_BPCreditWorthiness : Association to API_BUSINESS_PARTNER.A_BPCreditWorthiness {  };
  to_BPDataController : Association to many API_BUSINESS_PARTNER.A_BPDataController {  };
  to_BPEmployment : Association to many API_BUSINESS_PARTNER.A_BPEmployment {  };
  to_BPFinServicesReporting : Association to API_BUSINESS_PARTNER.A_BPFinancialServicesReporting {  };
  to_BPFiscalYearInformation : Association to many API_BUSINESS_PARTNER.A_BPFiscalYearInformation {  };
  to_BPRelationship : Association to many API_BUSINESS_PARTNER.A_BPRelationship {  };
  to_BPTaxCompliance : Association to many API_BUSINESS_PARTNER.A_BPTaxCompliance {  };
  to_BuPaIdentification : Association to many API_BUSINESS_PARTNER.A_BuPaIdentification {  };
  to_BuPaIndustry : Association to many API_BUSINESS_PARTNER.A_BuPaIndustry {  };
  to_BusinessPartner : Association to API_BUSINESS_PARTNER.A_BPFinancialServicesExtn {  };
  to_BusinessPartnerAddress : Association to many API_BUSINESS_PARTNER.A_BusinessPartnerAddress {  };
  to_BusinessPartnerAlias : Association to many API_BUSINESS_PARTNER.A_BusinessPartnerAlias {  };
  to_BusinessPartnerBank : Association to many API_BUSINESS_PARTNER.A_BusinessPartnerBank {  };
  to_BusinessPartnerContact : Association to many API_BUSINESS_PARTNER.A_BusinessPartnerContact {  };
  to_BusinessPartnerIsBank : Association to API_BUSINESS_PARTNER.A_BusinessPartnerIsBank {  };
  to_BusinessPartnerRating : Association to many API_BUSINESS_PARTNER.A_BusinessPartnerRating {  };
  to_BusinessPartnerRole : Association to many API_BUSINESS_PARTNER.A_BusinessPartnerRole {  };
  to_BusinessPartnerTax : Association to many API_BUSINESS_PARTNER.A_BusinessPartnerTaxNumber {  };
  to_BusPartAddrDepdntTaxNmbr : Association to many API_BUSINESS_PARTNER.A_BusPartAddrDepdntTaxNmbr {  };
  to_Customer : Association to API_BUSINESS_PARTNER.A_Customer {  };
  to_PaymentCard : Association to many API_BUSINESS_PARTNER.A_BusinessPartnerPaymentCard {  };
  to_Supplier : Association to API_BUSINESS_PARTNER.A_Supplier {  };
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Dirección'
entity API_BUSINESS_PARTNER.A_BusinessPartnerAddress {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Interloc.comercial'
  @sap.quickinfo : 'Número interlocutor comercial'
  key BusinessPartner : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº dirección'
  key AddressID : String(10) not null;
  @odata.Type : 'Edm.DateTimeOffset'
  @sap.label : 'Inicio validez'
  @sap.quickinfo : 'Inicio de validez de una dirección interlocutor comercial'
  ValidityStartDate : DateTime;
  @odata.Type : 'Edm.DateTimeOffset'
  @sap.label : 'Fin de validez'
  @sap.quickinfo : 'Fin de validez de dirección de interlocutor comercial'
  ValidityEndDate : DateTime;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo autorizaciones'
  @sap.quickinfo : 'Grupo de autorizaciones'
  AuthorizationGroup : String(4);
  @sap.label : 'UID de dirección de interlocutor comercial'
  @sap.heading : ''
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  AddressUUID : UUID;
  @sap.label : 'Calle 3'
  AdditionalStreetPrefixName : String(40);
  @sap.label : 'Calle 5'
  AdditionalStreetSuffixName : String(40);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Huso horario'
  @sap.quickinfo : 'Huso horario de la dirección'
  AddressTimeZone : String(6);
  @sap.label : 'c/o'
  @sap.quickinfo : 'Nombre c/o'
  CareOfName : String(40);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº de población'
  @sap.quickinfo : 'Codificación de población para fichero de población y calle'
  CityCode : String(12);
  @sap.label : 'Población'
  CityName : String(40);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cód.postal empresa'
  @sap.quickinfo : 'Código postal de la empresa (en caso de clientes import.)'
  CompanyPostalCode : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Clave de país/región'
  Country : String(3);
  @sap.label : 'Distrito'
  @sap.quickinfo : 'Distrito (US: County)'
  County : String(40);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Número serv.entrega'
  @sap.quickinfo : 'Número del servicio de entrega'
  DeliveryServiceNumber : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cl.serv.entrega'
  @sap.quickinfo : 'Clase del servicio de entrega'
  DeliveryServiceTypeCode : String(4);
  @sap.label : 'Distrito'
  District : String(40);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Tratamiento'
  @sap.quickinfo : 'Clave de tratamiento'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  FormOfAddress : String(4);
  @sap.label : 'Nombre completo'
  @sap.quickinfo : 'Nombre completo de parte (int.cial., un.org., direc.doc.)'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  FullName : String(80);
  @sap.label : 'Residencia alt.'
  @sap.quickinfo : 'Lugar de residencia (diferente de población cód.postal)'
  HomeCityName : String(40);
  @sap.label : 'Nº (edificio)'
  HouseNumber : String(10);
  @sap.label : 'Apéndice'
  @sap.quickinfo : 'Suplemento al número de casa'
  HouseNumberSupplementText : String(10);
  @sap.label : 'Clave de idioma'
  Language : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Apartado'
  POBox : String(10);
  @sap.label : 'Población apartado'
  @sap.quickinfo : 'Población del apartado'
  POBoxDeviatingCityName : String(40);
  @sap.display.format : 'UpperCase'
  @sap.label : 'País/reg.apartado'
  @sap.quickinfo : 'País/región de apartado de correos'
  POBoxDeviatingCountry : String(3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Región del apartado'
  @sap.quickinfo : 'Región del apartado (estado federal, land, provincia, etc.)'
  POBoxDeviatingRegion : String(3);
  @sap.label : 'Apartado sin nº'
  @sap.quickinfo : 'Indicador: Datos del apartado del correos sin número'
  POBoxIsWithoutNumber : Boolean;
  @sap.label : 'Estación ap.correos'
  @sap.quickinfo : 'Estación de apartado de correos (PO Box Lobby)'
  POBoxLobbyName : String(40);
  @sap.display.format : 'UpperCase'
  @sap.label : 'CP apartado'
  @sap.quickinfo : 'Código postal del apartado'
  POBoxPostalCode : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Número de persona'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  Person : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Código postal'
  @sap.quickinfo : 'Código postal de la población'
  PostalCode : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Forma comunicación'
  @sap.quickinfo : 'Forma de comunicación (clave) (Business Address Services)'
  PrfrdCommMediumType : String(3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Región'
  @sap.quickinfo : 'Región (Estado federal, Estado federado, provincia, condado)'
  Region : String(3);
  @sap.label : 'Calle'
  StreetName : String(60);
  @sap.label : 'Calle 2'
  StreetPrefixName : String(40);
  @sap.label : 'Calle 4'
  StreetSuffixName : String(40);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Domicilio fiscal'
  TaxJurisdiction : String(15);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Zona de transporte'
  @sap.quickinfo : 'Zona de transporte donde se efectúan las entregas'
  TransportZone : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Número direc.externo'
  @sap.quickinfo : 'Número de dirección en sistema externo'
  AddressIDByExternalSystem : String(20);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cód.ár.cir.'
  @sap.quickinfo : 'Código de área circular para área circular'
  CountyCode : String(8);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Código ciudad'
  @sap.quickinfo : 'Código de ciudad para ciudad'
  TownshipCode : String(8);
  @sap.label : 'Ciudad'
  TownshipName : String(40);
  to_AddressUsage : Association to many API_BUSINESS_PARTNER.A_BuPaAddressUsage {  };
  to_BPAddrDepdntIntlLocNumber : Association to API_BUSINESS_PARTNER.A_BPAddrDepdntIntlLocNumber {  };
  to_BPIntlAddressVersion : Association to many API_BUSINESS_PARTNER.A_BPIntlAddressVersion {  };
  to_EmailAddress : Association to many API_BUSINESS_PARTNER.A_AddressEmailAddress {  };
  to_FaxNumber : Association to many API_BUSINESS_PARTNER.A_AddressFaxNumber {  };
  to_MobilePhoneNumber : Association to many API_BUSINESS_PARTNER.A_AddressPhoneNumber {  };
  to_PhoneNumber : Association to many API_BUSINESS_PARTNER.A_AddressPhoneNumber {  };
  to_URLAddress : Association to many API_BUSINESS_PARTNER.A_AddressHomePageURL {  };
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Nombres adicionales'
entity API_BUSINESS_PARTNER.A_BusinessPartnerAlias {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Interloc.comercial'
  @sap.quickinfo : 'Número interlocutor comercial'
  key BusinessPartner : String(10) not null;
  @sap.display.format : 'NonNegative'
  @sap.label : 'Pos.nombres alias'
  @sap.quickinfo : 'Posiciones con nombres interlocutor comercial/nombres alias'
  key BPAliasPositionNumber : String(3) not null;
  @sap.label : 'Nombre alias'
  @sap.quickinfo : 'Nombre alias del interlocutor comercial'
  BusinessPartnerAliasName : String(80);
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Banco'
entity API_BUSINESS_PARTNER.A_BusinessPartnerBank {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Interloc.comercial'
  @sap.quickinfo : 'Número interlocutor comercial'
  key BusinessPartner : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'ID datos bancarios'
  key BankIdentification : String(4) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'País/región de banco'
  @sap.quickinfo : 'Clave de país/región del banco'
  BankCountryKey : String(3);
  @sap.label : 'Institución financ.'
  @sap.quickinfo : 'Nombre de la institución financiera'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  BankName : String(60);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Clave de banco'
  BankNumber : String(15);
  @sap.display.format : 'UpperCase'
  @sap.label : 'SWIFT/BIC'
  @sap.quickinfo : 'SWIFT/BIC para pagos internacionales'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  SWIFTCode : String(11);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Clave control bancos'
  @sap.quickinfo : 'Clave de control de bancos'
  BankControlKey : String(2);
  @sap.label : 'Titular de la cuenta'
  BankAccountHolderName : String(60);
  @sap.label : 'Denominación cuenta'
  @sap.quickinfo : 'Denominación datos bancarios'
  BankAccountName : String(40);
  @odata.Type : 'Edm.DateTimeOffset'
  @sap.label : 'Inicio validez'
  @sap.quickinfo : 'Inicio validez de datos bancarios de interlocutor comercial'
  ValidityStartDate : DateTime;
  @odata.Type : 'Edm.DateTimeOffset'
  @sap.label : 'Fin de validez'
  @sap.quickinfo : 'Fin validez de datos bancarios de interlocutor comercial'
  ValidityEndDate : DateTime;
  @sap.display.format : 'UpperCase'
  @sap.label : 'IBAN'
  @sap.quickinfo : 'IBAN (International Bank Account Number)'
  IBAN : String(34);
  @sap.display.format : 'Date'
  @sap.label : 'Inicio validez IBAN'
  @sap.quickinfo : 'Inicio de la validez del IBAN'
  IBANValidityStartDate : Date;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cuenta bancaria'
  @sap.quickinfo : 'Nº cuenta bancaria'
  BankAccount : String(18);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Dato de referencia'
  @sap.quickinfo : 'Dato de referencia para relación bancaria'
  BankAccountReferenceText : String(20);
  @sap.label : 'Autoriz.domic.'
  @sap.quickinfo : 'Indicador: Autorización de domiciliación'
  CollectionAuthInd : Boolean;
  @sap.label : 'Población'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  CityName : String(35);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo autorizaciones'
  @sap.quickinfo : 'Grupo de autorizaciones'
  AuthorizationGroup : String(4);
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Contacto'
entity API_BUSINESS_PARTNER.A_BusinessPartnerContact {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Número relación IC'
  @sap.quickinfo : 'Número de relación del interlocutor comercial'
  key RelationshipNumber : String(12) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Interloc.comercial'
  @sap.quickinfo : 'Número interlocutor comercial'
  key BusinessPartnerCompany : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Interloc.comercial'
  @sap.quickinfo : 'Número interlocutor comercial'
  key BusinessPartnerPerson : String(10) not null;
  @sap.display.format : 'Date'
  @sap.label : 'Fin de validez'
  @sap.quickinfo : 'Fecha de validez (válido a)'
  key ValidityEndDate : Date not null;
  @sap.display.format : 'Date'
  @sap.label : 'Inicio validez'
  @sap.quickinfo : 'Fecha de validez (válido de)'
  ValidityStartDate : Date;
  @sap.label : 'Estándar'
  @sap.quickinfo : 'Relación estándar'
  IsStandardRelationship : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Tipo de relación'
  @sap.quickinfo : 'Tipo de relación de interlocutor comercial'
  RelationshipCategory : String(6);
  to_ContactAddress : Association to many API_BUSINESS_PARTNER.A_BPContactToAddress {  };
  to_ContactRelationship : Association to API_BUSINESS_PARTNER.A_BPContactToFuncAndDept {  };
};

@cds.external : true
@cds.persistence.skip : true
@sap.deletable : 'false'
@sap.content.version : '1'
@sap.label : 'El socio es un banco'
entity API_BUSINESS_PARTNER.A_BusinessPartnerIsBank {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Interloc.comercial'
  @sap.quickinfo : 'Número interlocutor comercial'
  key BusinessPartner : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Clave de banco'
  BankKey : String(15);
  @sap.display.format : 'UpperCase'
  @sap.label : 'País/región de banco'
  @sap.quickinfo : 'Clave de país/región del banco'
  BankCountry : String(3);
  @sap.display.format : 'NonNegative'
  @sap.label : 'Reserva mín.oblig.'
  @sap.quickinfo : 'Reserva mínima obligatoria del instituto de crédito'
  BPMinimumReserve : String(1);
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Tarjeta de pago de socio comercial'
entity API_BUSINESS_PARTNER.A_BusinessPartnerPaymentCard {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Interloc.comercial'
  @sap.quickinfo : 'Número interlocutor comercial'
  key BusinessPartner : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'ID tarjeta de pago'
  @sap.quickinfo : 'ID de tarjeta de pago'
  key PaymentCardID : String(6) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cl.tarjeta pago'
  @sap.quickinfo : 'Clase tarjeta pago'
  key PaymentCardType : String(4) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº tarjeta'
  @sap.quickinfo : 'Tarjetas de pago: Número de tarjeta'
  key CardNumber : String(25) not null;
  @sap.label : 'Tarj.pag.std.'
  @sap.quickinfo : 'IC: Tarjeta pago estándar'
  IsStandardCard : Boolean;
  @sap.label : 'Denominación'
  @sap.quickinfo : 'Denominación de datos tarjeta de crédito'
  CardDescription : String(40);
  @sap.display.format : 'Date'
  @sap.label : 'Tarjeta válida desde'
  @sap.quickinfo : 'Tarjetas de pago: Válidas desde'
  ValidityDate : Date;
  @sap.display.format : 'Date'
  @sap.label : 'Tarj.validez hasta'
  @sap.quickinfo : 'Tarjetas de pago: Válidas hasta'
  ValidityEndDate : Date;
  @sap.label : 'Titular tarjeta'
  @sap.quickinfo : 'Tarjetas de pago: Nombre titular tarjeta'
  CardHolder : String(40);
  @sap.label : 'Banco emisor'
  @sap.quickinfo : 'Tarjetas pago: Banco emisor'
  CardIssuingBank : String(40);
  @sap.display.format : 'Date'
  @sap.label : 'Emitida el'
  @sap.quickinfo : 'Tarjetas de pago: Fecha de emisión'
  CardIssueDate : Date;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Bloqueo tarjeta'
  @sap.quickinfo : 'Tarjetas pago: Causa de bloqueo de una tarjeta de pago'
  PaymentCardLock : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº tarjeta'
  @sap.quickinfo : 'Número de tarjeta de pago enmascarado (pago digital)'
  MaskedCardNumber : String(25);
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Valoraciones'
entity API_BUSINESS_PARTNER.A_BusinessPartnerRating {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Interloc.comercial'
  @sap.quickinfo : 'Número interlocutor comercial'
  key BusinessPartner : String(10) not null;
  @sap.label : 'Proc.valoración'
  @sap.quickinfo : 'Proceso de valoración'
  key BusinessPartnerRatingProcedure : String(10) not null;
  @sap.display.format : 'Date'
  @sap.label : 'Fin validez valorac.'
  @sap.quickinfo : 'Fin de validez de valoración'
  key BPRatingValidityEndDate : Date not null;
  @sap.label : 'Valoración'
  BusinessPartnerRatingGrade : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Tendencia'
  BusinessPartnerRatingTrend : String(2);
  @sap.display.format : 'Date'
  @sap.label : 'Inic.valid.valorac.'
  @sap.quickinfo : 'Inicio de validez de valoración'
  BPRatingValidityStartDate : Date;
  @sap.display.format : 'Date'
  @sap.label : 'Valorado el'
  @sap.quickinfo : 'Fecha de entrada de valoración'
  BPRatingCreationDate : Date;
  @sap.label : 'Texto'
  @sap.quickinfo : 'Textos para valoraciones'
  BusinessPartnerRatingComment : String(60);
  @sap.label : 'Autoriz.valoración'
  @sap.quickinfo : 'Autorización de valoración'
  BusinessPartnerRatingIsAllowed : Boolean;
  @sap.label : 'Valoración válida'
  @sap.quickinfo : 'La valoración del intermediario fin.es válida en fecha clave'
  BPRatingIsValidOnKeyDate : Boolean;
  @sap.display.format : 'Date'
  @sap.label : 'Fecha de acceso'
  @sap.quickinfo : 'Fecha clave de acceso a datos de valoración IF'
  BusinessPartnerRatingKeyDate : Date;
  @sap.label : 'Valoración vencida'
  @sap.quickinfo : 'Validez de valoración ha vencido según el período permitido'
  BusinessPartnerRatingIsExpired : Boolean;
};

@cds.external : true
@cds.persistence.skip : true
@sap.deletable : 'false'
@sap.content.version : '1'
@sap.label : 'Rol'
entity API_BUSINESS_PARTNER.A_BusinessPartnerRole {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Interloc.comercial'
  @sap.quickinfo : 'Número interlocutor comercial'
  key BusinessPartner : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Rol de SC'
  @sap.quickinfo : 'Función IC'
  key BusinessPartnerRole : String(6) not null;
  @odata.Type : 'Edm.DateTimeOffset'
  @sap.label : 'Inicio validez'
  @sap.quickinfo : 'Inicio de validez de una función IC'
  ValidFrom : DateTime;
  @odata.Type : 'Edm.DateTimeOffset'
  @sap.label : 'Fin de validez'
  @sap.quickinfo : 'Fin de validez de una función IC'
  ValidTo : DateTime;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo autorizaciones'
  @sap.quickinfo : 'Grupo de autorizaciones'
  AuthorizationGroup : String(4);
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Nº de identificación fiscal (CE)'
entity API_BUSINESS_PARTNER.A_BusinessPartnerTaxNumber {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Interloc.comercial'
  @sap.quickinfo : 'Número interlocutor comercial'
  key BusinessPartner : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Tipo de N.I.F.'
  @sap.quickinfo : 'Tipo de número identificación fiscal'
  key BPTaxType : String(4) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'N.I.F.'
  @sap.quickinfo : 'NIF para interlocutor comercial'
  BPTaxNumber : String(20);
  @sap.display.format : 'UpperCase'
  @sap.label : 'N.I.F. largo'
  @sap.quickinfo : 'Número de identificación fiscal del interlocutor comercial'
  BPTaxLongNumber : String(60);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo autorizaciones'
  @sap.quickinfo : 'Grupo de autorizaciones'
  AuthorizationGroup : String(4);
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Números de impuesto dependientes dirección socio comercial'
entity API_BUSINESS_PARTNER.A_BusPartAddrDepdntTaxNmbr {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Interloc.comercial'
  @sap.quickinfo : 'Número interlocutor comercial'
  key BusinessPartner : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº dirección'
  key AddressID : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Tipo de N.I.F.'
  @sap.quickinfo : 'Tipo de número identificación fiscal'
  key BPTaxType : String(4) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'N.I.F.'
  @sap.quickinfo : 'NIF para interlocutor comercial'
  BPTaxNumber : String(20);
  @sap.display.format : 'UpperCase'
  @sap.label : 'N.I.F. largo'
  @sap.quickinfo : 'Número de identificación fiscal del interlocutor comercial'
  BPTaxLongNumber : String(60);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo autorizaciones'
  @sap.quickinfo : 'Grupo de autorizaciones'
  AuthorizationGroup : String(4);
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Identificador externo dependiente dirección cliente'
entity API_BUSINESS_PARTNER.A_CustAddrDepdntExtIdentifier {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cliente'
  @sap.quickinfo : 'Número de cliente'
  key Customer : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº dirección'
  @sap.quickinfo : 'Número dirección interloc.comercial (de BUT020)'
  key AddressID : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'IDDirClteDefVended'
  @sap.quickinfo : 'ID de dirección de cliente definido por vendedor para EDI'
  CustomerExternalRefID : String(12);
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Información dependiente de dirección de cliente'
entity API_BUSINESS_PARTNER.A_CustAddrDepdntInformation {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cliente'
  @sap.quickinfo : 'Número de cliente'
  key Customer : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº dirección'
  @sap.quickinfo : 'Número dirección interloc.comercial (de BUT020)'
  key AddressID : String(10) not null;
  @sap.label : 'Estac.ferroc.expreso'
  @sap.quickinfo : 'Estación de ferrocarril para envío por expreso'
  ExpressTrainStationName : String(25);
  @sap.label : 'Estación de tren'
  TrainStationName : String(25);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Código de lugar'
  CityCode : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Código de condado'
  County : String(3);
};

@cds.external : true
@cds.persistence.skip : true
@sap.creatable : 'false'
@sap.deletable : 'false'
@sap.content.version : '1'
@sap.label : 'Deudor (cliente)'
entity API_BUSINESS_PARTNER.A_Customer {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cliente'
  @sap.quickinfo : 'Número de cliente'
  key Customer : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Autorización'
  @sap.quickinfo : 'Grupo autorizaciones'
  AuthorizationGroup : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Bloqueo factura'
  @sap.quickinfo : 'Bloqueo central de factura para cliente'
  BillingIsBlockedForCustomer : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Creado por'
  @sap.quickinfo : 'Nombre del responsable que ha añadido el objeto'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  CreatedByUser : String(12);
  @sap.display.format : 'Date'
  @sap.label : 'Creado el'
  @sap.quickinfo : 'Fecha de creación del registro'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  CreationDate : Date;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo de cuentas'
  @sap.quickinfo : 'Grupo de ctas.deudor'
  CustomerAccountGroup : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Clasific.clientes'
  @sap.quickinfo : 'Clasificación de clientes'
  CustomerClassification : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nombre del cliente'
  @sap.quickinfo : 'Nombre completo de cliente'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  CustomerFullName : String(220);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nombre del cliente'
  @sap.quickinfo : 'Nombre completo de cliente'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  BPCustomerFullName : String(220);
  @sap.label : 'Nombre de cliente'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  CustomerName : String(80);
  @sap.label : 'Nombre de cliente'
  @sap.quickinfo : 'Nombre del cliente'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  BPCustomerName : String(81);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Bloqueo entrega'
  @sap.quickinfo : 'Bloqueo central de entrega para cliente'
  DeliveryIsBlocked : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Factura'
  @sap.quickinfo : 'Atributo 1'
  FreeDefinedAttribute01 : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Guía de Remisión'
  @sap.quickinfo : 'Atributo 2'
  FreeDefinedAttribute02 : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'OC–Orden Compra'
  @sap.quickinfo : 'Atributo 3'
  FreeDefinedAttribute03 : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'PI-Parte Ingres'
  @sap.quickinfo : 'Atributo 4'
  FreeDefinedAttribute04 : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'DJ-Decl. Jurada'
  @sap.quickinfo : 'Atributo 5'
  FreeDefinedAttribute05 : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'FS-Ficha Sintom'
  @sap.quickinfo : 'Atributo 6'
  FreeDefinedAttribute06 : String(3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'FT-Ficha Técnic'
  @sap.quickinfo : 'Atributo 7'
  FreeDefinedAttribute07 : String(3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Carta Garantía'
  @sap.quickinfo : 'Atributo 8'
  FreeDefinedAttribute08 : String(3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Requiere Cita'
  FreeDefinedAttribute09 : String(3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Termosellado'
  FreeDefinedAttribute10 : String(3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Persona física'
  NFPartnerIsNaturalPerson : String(1);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Bloqueo pedido'
  @sap.quickinfo : 'Bloqueo central de pedido para cliente'
  OrderIsBlockedForCustomer : String(2);
  @sap.label : 'Bloqueo contab.'
  @sap.quickinfo : 'Bloqueo contabilización central'
  PostingIsBlocked : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Proveedor'
  @sap.quickinfo : 'Número de cuenta del proveedor o acreedor'
  Supplier : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Clave de grupo'
  CustomerCorporateGroup : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Domicilio fiscal'
  @sap.quickinfo : 'Número de cta. del reg. maestro con domicilio fiscal'
  FiscalAddress : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Ramo'
  @sap.quickinfo : 'Clave de ramo industrial'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  Industry : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Código de ramo 1'
  IndustryCode1 : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Código ramo 2'
  @sap.quickinfo : 'Código de ramo 2'
  IndustryCode2 : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Código ramo 3'
  @sap.quickinfo : 'Código de ramo 3'
  IndustryCode3 : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Código ramo 4'
  @sap.quickinfo : 'Código de ramo 4'
  IndustryCode4 : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Código ramo 5'
  @sap.quickinfo : 'Código de ramo 5'
  IndustryCode5 : String(10);
  @sap.display.format : 'NonNegative'
  @sap.label : 'Núm.ubicación int.1'
  @sap.quickinfo : 'International Location Number (parte 1)'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  InternationalLocationNumber1 : String(7);
  @sap.display.format : 'NonNegative'
  @sap.label : 'Núm.ubicación int.2'
  @sap.quickinfo : 'Número de ubicación internacional (parte 2)'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  InternationalLocationNumber2 : String(5);
  @sap.display.format : 'NonNegative'
  @sap.label : 'Dígito de control'
  @sap.quickinfo : 'Dígito de control para el Nº de empresa internacional'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  InternationalLocationNumber3 : String(1);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Distrito Nielsen'
  NielsenRegion : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Motivo de pago'
  PaymentReason : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Clase de impuesto'
  ResponsibleType : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº ident.fis.1'
  @sap.quickinfo : 'Número de identificación fiscal 1'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  TaxNumber1 : String(16);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº ident.fis.2'
  @sap.quickinfo : 'Número de identificación fiscal suplementario'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  TaxNumber2 : String(11);
  @sap.display.format : 'UpperCase'
  @sap.label : 'NIF 3'
  @sap.quickinfo : 'Número identificación fiscal 3'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  TaxNumber3 : String(18);
  @sap.display.format : 'UpperCase'
  @sap.label : 'NIF 4'
  @sap.quickinfo : 'Número identificación fiscal 4'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  TaxNumber4 : String(18);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Número fiscal 5'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  TaxNumber5 : String(60);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Tipo NIF'
  @sap.quickinfo : 'Tipo de número de identificación fiscal'
  TaxNumberType : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'N.I.F. comunitario'
  @sap.quickinfo : 'Número de identificación fiscal comunitario'
  VATRegistration : String(20);
  @sap.label : 'Pet.borrado'
  @sap.quickinfo : 'Petición borrado central p.registro maestro'
  DeletionIndicator : Boolean;
  @sap.label : 'Estac.ferroc.expreso'
  @sap.quickinfo : 'Estación de ferrocarril para envío por expreso'
  ExpressTrainStationName : String(25);
  @sap.label : 'Estación de tren'
  TrainStationName : String(25);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Código de lugar'
  CityCode : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Código de condado'
  County : String(3);
  @sap.field.control : 'ZZ1_EPP2_cusF'
  @sap.label : 'EPP'
  @sap.is.extension.field : 'true'
  ZZ1_EPP2_cus : Boolean;
  @sap.field.control : 'ZZ1_ETIQUETADO_cusF'
  @sap.label : 'Etiquetado'
  @sap.is.extension.field : 'true'
  ZZ1_ETIQUETADO_cus : Boolean;
  @sap.field.control : 'ZZ1_GRPCLIENT1_cusF'
  @sap.text : 'ZZ1_GRPCLIENT1_cusT'
  @sap.label : 'Grupo de clientes 1'
  @sap.value.list : 'standard'
  @sap.is.extension.field : 'true'
  ZZ1_GRPCLIENT1_cus : String(2);
  @sap.field.control : 'ZZ1_PALETIZADO_cusF'
  @sap.label : 'Paletizado'
  @sap.is.extension.field : 'true'
  ZZ1_PALETIZADO_cus : Boolean;
  @sap.field.control : 'ZZ1_COLORCAS_cusF'
  @sap.label : 'Color casco'
  @sap.is.extension.field : 'true'
  ZZ1_COLORCAS_cus : String(10);
  @sap.field.control : 'ZZ1_REQIND2_cusF'
  @sap.label : 'Requiere inducción'
  @sap.is.extension.field : 'true'
  ZZ1_REQIND2_cus : Boolean;
  @sap.field.control : 'ZZ1_SOTANO2_cusF'
  @sap.text : 'ZZ1_SOTANO2_cusT'
  @sap.label : 'Sótano'
  @sap.value.list : 'standard'
  @sap.is.extension.field : 'true'
  ZZ1_SOTANO2_cus : String(1);
  @sap.field.control : 'ZZ1_EXCLUSIV2_cusF'
  @sap.label : 'Exclusividad'
  @sap.is.extension.field : 'true'
  ZZ1_EXCLUSIV2_cus : String(30);
  @sap.field.control : 'ZZ1_ENZUNCH_cusF'
  @sap.label : 'Enzunchado'
  @sap.is.extension.field : 'true'
  ZZ1_ENZUNCH_cus : Boolean;
  @sap.field.control : 'ZZ1_OTROS_cusF'
  @sap.label : 'Otros'
  @sap.is.extension.field : 'true'
  ZZ1_OTROS_cus : String(50);
  @sap.display.format : 'NonNegative'
  @sap.field.control : 'ZZ1_TIEMPOE_cusF'
  @sap.label : 'Tiempo de Espera'
  @sap.is.extension.field : 'true'
  ZZ1_TIEMPOE_cus : String(4);
  @sap.field.control : 'ZZ1_REQINDU_cusF'
  @sap.label : 'Requiere inducción'
  @sap.is.extension.field : 'true'
  ZZ1_REQINDU_cus : Boolean;
  @sap.field.control : 'ZZ1_IMPESPEC_cusF'
  @sap.label : 'Implemento especial'
  @sap.is.extension.field : 'true'
  ZZ1_IMPESPEC_cus : String(20);
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_COLORCAS_cusF : Integer;
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_ENZUNCH_cusF : Integer;
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_EPP2_cusF : Integer;
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_ETIQUETADO_cusF : Integer;
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_EXCLUSIV2_cusF : Integer;
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_GRPCLIENT1_cusF : Integer;
  @sap.field.control : 'ZZ1_GRPCLIENT1_cusF'
  @sap.label : 'Descripción'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_GRPCLIENT1_cusT : String(60);
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_IMPESPEC_cusF : Integer;
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_OTROS_cusF : Integer;
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_PALETIZADO_cusF : Integer;
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_REQIND2_cusF : Integer;
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_REQINDU_cusF : Integer;
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_SOTANO2_cusF : Integer;
  @sap.field.control : 'ZZ1_SOTANO2_cusF'
  @sap.label : 'Descripción'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_SOTANO2_cusT : String(60);
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_TIEMPOE_cusF : Integer;
  to_CustAddrDepdntExtIdentifier : Association to many API_BUSINESS_PARTNER.A_CustAddrDepdntExtIdentifier {  };
  to_CustAddrDepdntInformation : Association to many API_BUSINESS_PARTNER.A_CustAddrDepdntInformation {  };
  to_CustomerCompany : Association to many API_BUSINESS_PARTNER.A_CustomerCompany {  };
  to_CustomerSalesArea : Association to many API_BUSINESS_PARTNER.A_CustomerSalesArea {  };
  to_CustomerTaxGrouping : Association to many API_BUSINESS_PARTNER.A_CustomerTaxGrouping {  };
  to_CustomerText : Association to many API_BUSINESS_PARTNER.A_CustomerText {  };
  to_CustomerUnloadingPoint : Association to many API_BUSINESS_PARTNER.A_CustomerUnloadingPoint {  };
  to_CustUnldgPtAddrDepdntInfo : Association to many API_BUSINESS_PARTNER.A_CustUnldgPtAddrDepdntInfo {  };
};

@cds.external : true
@cds.persistence.skip : true
@sap.deletable : 'false'
@sap.content.version : '1'
@sap.label : 'Empresa cliente'
entity API_BUSINESS_PARTNER.A_CustomerCompany {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cliente'
  @sap.quickinfo : 'Número de cliente'
  key Customer : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Sociedad'
  key CompanyCode : String(4) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo tolerancia'
  @sap.quickinfo : 'Grupo de tolerancia p.interlocutor comercial/cta.may.'
  APARToleranceGroup : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cuenta en el deudor'
  @sap.quickinfo : 'Nuestro número de cuenta con el deudor'
  AccountByCustomer : String(12);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Abrev.respons.'
  @sap.quickinfo : 'Abreviatura del pesponsable de contabilidad'
  AccountingClerk : String(2);
  @sap.label : 'Telefaz encargado'
  @sap.quickinfo : 'Telefax del encargado en el interlocutor comercial'
  AccountingClerkFaxNumber : String(31);
  @sap.label : 'Direc.Internet resp.'
  @sap.quickinfo : 'Dirección Internet del responsable del interlocutor comerc.'
  AccountingClerkInternetAddress : String(130);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Teléfono responsable'
  @sap.quickinfo : 'Número de teléfono del responsable en interlocutor comercial'
  AccountingClerkPhoneNumber : String(30);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Pagador alternativo'
  @sap.quickinfo : 'Número de cuenta del pagador alternativo'
  AlternativePayerAccount : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Autorización'
  @sap.quickinfo : 'Grupo autorizaciones'
  AuthorizationGroup : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Variante fact.col.'
  @sap.quickinfo : 'Variante de facturación colectiva'
  CollectiveInvoiceVariant : String(1);
  @sap.label : 'Nota interior cuenta'
  @sap.quickinfo : 'Nota'
  CustomerAccountNote : String(30);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Central'
  @sap.quickinfo : 'Núm.de cuenta de la central (para cuentas de subsidiarias)'
  CustomerHeadOffice : String(10);
  @sap.label : 'Compensar c/acreedor'
  @sap.quickinfo : 'Indicador: ¿Compensación entre deudor y acreedor?'
  CustomerSupplierClearingIsUsed : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Banco propio'
  @sap.quickinfo : 'Clave breve para banco propio'
  HouseBank : String(5);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Indicador intereses'
  @sap.quickinfo : 'Indicador de intereses'
  InterestCalculationCode : String(2);
  @sap.display.format : 'Date'
  @sap.label : 'Últ.fecha clv.'
  @sap.quickinfo : 'Fecha clave del último cálculo de intereses'
  InterestCalculationDate : Date;
  @sap.display.format : 'NonNegative'
  @sap.label : 'Ritmo ints.'
  @sap.quickinfo : 'Ritmo del cálculo de intereses en meses'
  IntrstCalcFrequencyInMonths : String(2);
  @sap.label : 'Trat. no centraliz.'
  @sap.quickinfo : 'Indicador: Tratamiento no centralizado'
  IsToBeLocallyProcessed : Boolean;
  @sap.label : 'Pago único'
  @sap.quickinfo : 'Indicador: Pagar todas las partidas individualmente'
  ItemIsToBePaidSeparately : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Clave clasificación'
  @sap.quickinfo : 'Clave para clasificar por números de asignación'
  LayoutSortingRule : String(3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Bloqueo de pago'
  @sap.quickinfo : 'Clave de bloqueo para el pago'
  PaymentBlockingReason : String(1);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Vías de pago'
  @sap.quickinfo : 'Lista de las vías de pago a tener en cuenta'
  PaymentMethodsList : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Motivo de pago'
  PaymentReason : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Condiciones de pago'
  @sap.quickinfo : 'Clave de condiciones de pago'
  PaymentTerms : String(4);
  @sap.label : 'Aviso pago por EDI'
  @sap.quickinfo : 'Indicador: Enviar avisos de pago por EDI'
  PaytAdviceIsSentbyEDI : Boolean;
  @sap.label : 'Bloq.contab.p.soc.'
  @sap.quickinfo : 'Bloqueo de contabilización para sociedad'
  PhysicalInventoryBlockInd : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cuenta asociada'
  @sap.quickinfo : 'Cuenta asociada en la contabilidad principal'
  ReconciliationAccount : String(10);
  @sap.label : 'Anotar historial'
  @sap.quickinfo : 'Indicador: ¿Registrar historial de pagos?'
  RecordPaymentHistoryIndicator : Boolean;
  @sap.label : 'Responsable deudor'
  @sap.quickinfo : 'Responsable en el deudor'
  UserAtCustomer : String(15);
  @sap.label : 'Petic.borrado soc.'
  @sap.quickinfo : 'Petición de borrado p.registro maestro (nivel de sociedad)'
  DeletionIndicator : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo de tesorería'
  CashPlanningGroup : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Acuerdo vacaciones'
  @sap.quickinfo : 'Clave breve para acuerdo de vacaciones'
  KnownOrNegotiatedLeave : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Amo acumulada'
  @sap.quickinfo : 'Clave de amortización acumulada'
  ValueAdjustmentKey : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo de cuentas'
  @sap.quickinfo : 'Grupo de ctas.deudor'
  CustomerAccountGroup : String(4);
  to_CompanyText : Association to many API_BUSINESS_PARTNER.A_CustomerCompanyText {  };
  to_CustomerDunning : Association to many API_BUSINESS_PARTNER.A_CustomerDunning {  };
  to_WithHoldingTax : Association to many API_BUSINESS_PARTNER.A_CustomerWithHoldingTax {  };
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Texto de sociedad de cliente'
entity API_BUSINESS_PARTNER.A_CustomerCompanyText {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cliente'
  @sap.quickinfo : 'Número de cliente'
  key Customer : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Sociedad'
  key CompanyCode : String(4) not null;
  @sap.label : 'Idioma'
  @sap.quickinfo : 'Clave de idioma'
  key Language : String(2) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'ID texto'
  @sap.quickinfo : 'ID de texto'
  key LongTextID : String(4) not null;
  @sap.label : 'String'
  @sap.heading : ''
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.sortable : 'false'
  @sap.filterable : 'false'
  LongText : String;
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Reclamación de cliente'
entity API_BUSINESS_PARTNER.A_CustomerDunning {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cliente'
  @sap.quickinfo : 'Número de cliente'
  key Customer : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Sociedad'
  key CompanyCode : String(4) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Área de reclamación'
  key DunningArea : String(2) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Bloqueo reclam.'
  @sap.quickinfo : 'Bloqueo de reclamación'
  DunningBlock : String(1);
  @sap.display.format : 'NonNegative'
  @sap.label : 'Nivel reclamación'
  @sap.quickinfo : 'Nivel de reclamación'
  DunningLevel : String(1);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Proced.reclamación'
  @sap.quickinfo : 'Procedimiento de reclamación'
  DunningProcedure : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Receptor reclamación'
  @sap.quickinfo : 'Número de cuenta del receptor de la reclamación'
  DunningRecipient : String(10);
  @sap.display.format : 'Date'
  @sap.label : 'Última reclam.'
  @sap.quickinfo : 'Fecha de la última reclamación'
  LastDunnedOn : Date;
  @sap.display.format : 'Date'
  @sap.label : 'Reclam.judicial del'
  @sap.quickinfo : 'Fecha del procedimiento de reclamación judicial'
  LegDunningProcedureOn : Date;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Respons.reclamación'
  @sap.quickinfo : 'Responsable de la reclamación'
  DunningClerk : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Autorización'
  @sap.quickinfo : 'Grupo autorizaciones'
  AuthorizationGroup : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo de cuentas'
  @sap.quickinfo : 'Grupo de ctas.deudor'
  CustomerAccountGroup : String(4);
};

@cds.external : true
@cds.persistence.skip : true
@sap.deletable : 'false'
@sap.content.version : '1'
@sap.label : 'Área de ventas'
entity API_BUSINESS_PARTNER.A_CustomerSalesArea {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cliente'
  @sap.quickinfo : 'Número de cliente'
  key Customer : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Organización ventas'
  @sap.quickinfo : 'Organización de ventas'
  key SalesOrganization : String(4) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Canal distribución'
  @sap.quickinfo : 'Canal de distribución'
  key DistributionChannel : String(2) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Sector'
  key Division : String(2) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cuenta en el deudor'
  @sap.quickinfo : 'Nuestra cuenta con el cliente / proveedor'
  AccountByCustomer : String(12);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo autorizaciones'
  @sap.quickinfo : 'Grupo de autorizaciones'
  AuthorizationGroup : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'BlFactÁreaVtas'
  @sap.quickinfo : 'Bloqueo de factura para cliente (nivel comercial)'
  BillingIsBlockedForCustomer : String(2);
  @sap.label : 'Entrega completa'
  @sap.quickinfo : 'Completar entrega definida para cada pedido de cliente'
  CompleteDeliveryIsDefined : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Área ctrl.créditos'
  @sap.quickinfo : 'Área de control de créditos'
  CreditControlArea : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Moneda'
  @sap.semantics : 'currency-code'
  Currency : String(5);
  @sap.label : 'Gestión liquidación'
  @sap.quickinfo : 'Indicador: Relevante para gestión de liquidación'
  CustIsRlvtForSettlmtMgmt : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Clasificación ABC'
  @sap.quickinfo : 'Clasificación de clientes (Análisis ABC)'
  CustomerABCClassification : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Gr.imputación clte.'
  @sap.quickinfo : 'Grupo de imputación para este cliente'
  CustomerAccountAssignmentGroup : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo de clientes'
  CustomerGroup : String(2);
  @sap.label : 'Rappel'
  @sap.quickinfo : 'Indicador: Cliente relevante para rappel'
  CustomerIsRebateRelevant : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Condiciones de pago'
  @sap.quickinfo : 'Clave de condiciones de pago'
  CustomerPaymentTerms : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo precio cliente'
  @sap.quickinfo : 'Grupo de precios de cliente'
  CustomerPriceGroup : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Esquema de cliente'
  @sap.quickinfo : 'Clasificación cliente para determinar esquema de cálculo'
  CustomerPricingProcedure : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Esq.clte.prop.prod.'
  @sap.quickinfo : 'Esquema clte.: Propuesta prod.'
  CustProdProposalProcedure : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'BloqEntÁreaVtas'
  @sap.quickinfo : 'Bloqueo de entrega para cliente (nivel comercial)'
  DeliveryIsBlockedForCustomer : String(2);
  @sap.display.format : 'NonNegative'
  @sap.label : 'Prioridad de entrega'
  DeliveryPriority : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Incoterms'
  @sap.quickinfo : 'Incoterms parte 1'
  IncotermsClassification : String(3);
  @sap.label : 'Ubic.incoterms 2'
  @sap.quickinfo : 'Ubicación de incoterms 2'
  IncotermsLocation2 : String(70);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Versión de Incoterms'
  IncotermsVersion : String(4);
  @sap.label : 'Ubicac.incoterms 1'
  @sap.quickinfo : 'Ubicación de incoterms 1'
  IncotermsLocation1 : String(70);
  @sap.label : 'UUID de ubicación'
  IncotermsSupChnLoc1AddlUUID : UUID;
  @sap.label : 'UUID de ubicación'
  IncotermsSupChnLoc2AddlUUID : UUID;
  @sap.label : 'UUID de ubicación'
  IncotermsSupChnDvtgLocAddlUUID : UUID;
  @sap.label : 'PetBorrÁreaVtas'
  @sap.quickinfo : 'Petición de borrado para cliente (a nivel comercial)'
  DeletionIndicator : Boolean;
  @sap.label : 'Incoterms, parte 2'
  IncotermsTransferLocation : String(28);
  @sap.label : 'Determinación precio'
  @sap.quickinfo : 'Indicador relevante para determinación de precios'
  InspSbstHasNoTimeOrQuantity : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Fechas facturación'
  @sap.quickinfo : 'Fechas de facturación (identificación de calendario)'
  InvoiceDate : String(2);
  @sap.display.format : 'NonNegative'
  @sap.label : 'Probabilidad pedido'
  @sap.quickinfo : 'Probabilidad de pedido de posición'
  ItemOrderProbabilityInPercent : String(3);
  @sap.label : 'Actual.man.factura'
  @sap.quickinfo : 'Actualización manual de factura'
  ManualInvoiceMaintIsRelevant : Boolean;
  @sap.label : 'Máx.entreg.parciales'
  @sap.quickinfo : 'Cantidad máxima de entregas parciales permitidas p/posición'
  MaxNmbrOfPartialDelivery : Decimal(1, 0);
  @sap.label : 'Agrupamiento pedidos'
  @sap.quickinfo : 'Indicador de agrupamiento de pedidos'
  OrderCombinationIsAllowed : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'BloqPedÁreaVtas'
  @sap.quickinfo : 'Bloqueo de pedido para cliente (área de ventas)'
  OrderIsBlockedForCustomer : String(2);
  @sap.label : 'Tol.exc.suministro'
  @sap.quickinfo : 'Tolerancia de exceso de suministro'
  OverdelivTolrtdLmtRatioInPct : Decimal(3, 1);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Entrega parcial/pos.'
  @sap.quickinfo : 'Entrega parcial a nivel de posición'
  PartialDeliveryIsAllowed : String(1);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Tp.lista de precios'
  @sap.quickinfo : 'Tipo de lista de precios'
  PriceListType : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo un.medida'
  @sap.quickinfo : 'Grupo de unidades de medida'
  ProductUnitGroup : String(4);
  @sap.label : 'Vent.tiempo ARE'
  @sap.quickinfo : 'Período tiempo p.notificación acuse recibo entrega'
  ProofOfDeliveryTimeValue : Decimal(6, 2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo de vendedores'
  SalesGroup : String(3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Propuesta posiciones'
  @sap.quickinfo : 'Propuesta de posiciones'
  SalesItemProposal : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Oficina de ventas'
  SalesOffice : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cond.expedición'
  @sap.quickinfo : 'Condiciones de expedición'
  ShippingCondition : String(2);
  @sap.label : 'Relevante ARE'
  @sap.quickinfo : 'Relevante p.gestión ARE'
  SlsDocIsRlvtForProofOfDeliv : Boolean;
  @sap.label : 'Tol.ilimitada'
  @sap.quickinfo : 'Exceso de suministro ilimitado permitido'
  SlsUnlmtdOvrdelivIsAllwd : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Centro suministrador'
  @sap.quickinfo : 'Centro suministrador (propio o externo)'
  SupplyingPlant : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Zona de ventas'
  SalesDistrict : String(6);
  @sap.label : 'Toler.faltas sumin.'
  @sap.quickinfo : 'Tolerancia de suministro incompleto'
  UnderdelivTolrtdLmtRatioInPct : Decimal(3, 1);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Progr.lista facturas'
  @sap.quickinfo : 'Programa de lista de facturas (identificación de calendario)'
  InvoiceListSchedule : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cl.tipo de cambio'
  @sap.quickinfo : 'Clase de tipo de cambio'
  ExchangeRateType : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Paletizado'
  AdditionalCustomerGroup1 : String(3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo de clientes 2'
  AdditionalCustomerGroup2 : String(3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo de clientes 3'
  AdditionalCustomerGroup3 : String(3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo de clientes 4'
  @sap.quickinfo : 'Grupo de clientes 1'
  AdditionalCustomerGroup4 : String(3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo de clientes 5'
  AdditionalCustomerGroup5 : String(3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Esquema de garantías'
  @sap.quickinfo : 'Esquema de garantías de pago cliente'
  PaymentGuaranteeProcedure : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo de cuentas'
  @sap.quickinfo : 'Grupo de ctas.deudor'
  CustomerAccountGroup : String(4);
  @sap.field.control : 'ZZ1_COLCAS_csaF'
  @sap.label : 'Color casco'
  @sap.is.extension.field : 'true'
  ZZ1_COLCAS_csa : String(10);
  @sap.field.control : 'ZZ1_EPP_csaF'
  @sap.label : 'EPP'
  @sap.is.extension.field : 'true'
  ZZ1_EPP_csa : Boolean;
  @sap.field.control : 'ZZ1_TIEMPO_csaF'
  @sap.label : 'Tiempo de Espera'
  @sap.is.extension.field : 'true'
  ZZ1_TIEMPO_csa : String(4);
  @sap.field.control : 'ZZ1_REQCIT_csaF'
  @sap.label : 'Requiere cita'
  @sap.is.extension.field : 'true'
  ZZ1_REQCIT_csa : Boolean;
  @sap.field.control : 'ZZ1_ENSUNC_csaF'
  @sap.label : 'Enzunchado'
  @sap.is.extension.field : 'true'
  ZZ1_ENSUNC_csa : Boolean;
  @sap.field.control : 'ZZ1_COPIAS_FT_csaF'
  @sap.label : 'Nro Copias FT'
  @sap.is.extension.field : 'true'
  ZZ1_COPIAS_FT_csa : String(5);
  @sap.field.control : 'ZZ1_FICSINT_csaF'
  @sap.label : 'Ficha Sintomatológica'
  @sap.is.extension.field : 'true'
  ZZ1_FICSINT_csa : Boolean;
  @sap.field.control : 'ZZ1_REQIND_csaF'
  @sap.label : 'Requiere inducción'
  @sap.is.extension.field : 'true'
  ZZ1_REQIND_csa : Boolean;
  @sap.field.control : 'ZZ1_TERMO_csaF'
  @sap.label : 'Termosellado'
  @sap.is.extension.field : 'true'
  ZZ1_TERMO_csa : Boolean;
  @sap.field.control : 'ZZ1_DECJUR_csaF'
  @sap.label : 'Declaración jurada'
  @sap.is.extension.field : 'true'
  ZZ1_DECJUR_csa : Boolean;
  @sap.field.control : 'ZZ1_ROTESP_csaF'
  @sap.label : 'Rótulo especial'
  @sap.is.extension.field : 'true'
  ZZ1_ROTESP_csa : Boolean;
  @sap.field.control : 'ZZ1_CITPLA_csaF'
  @sap.label : 'Cita con placa'
  @sap.is.extension.field : 'true'
  ZZ1_CITPLA_csa : Boolean;
  @sap.field.control : 'ZZ1_COPIAS_GR_csaF'
  @sap.label : 'Nro Copias GR'
  @sap.is.extension.field : 'true'
  ZZ1_COPIAS_GR_csa : String(5);
  @sap.field.control : 'ZZ1_EXCLUSIV_csaF'
  @sap.label : 'Exclusividad'
  @sap.is.extension.field : 'true'
  ZZ1_EXCLUSIV_csa : String(30);
  @sap.field.control : 'ZZ1_FICTECN_csaF'
  @sap.label : 'Ficha Técnica'
  @sap.is.extension.field : 'true'
  ZZ1_FICTECN_csa : Boolean;
  @sap.field.control : 'ZZ1_SOTANO_csaF'
  @sap.label : 'Sótano'
  @sap.is.extension.field : 'true'
  ZZ1_SOTANO_csa : Boolean;
  @sap.field.control : 'ZZ1_PALETI_csaF'
  @sap.label : 'Paletizado'
  @sap.is.extension.field : 'true'
  ZZ1_PALETI_csa : Boolean;
  @sap.field.control : 'ZZ1_IMPESP_csaF'
  @sap.label : 'Implemento especial'
  @sap.is.extension.field : 'true'
  ZZ1_IMPESP_csa : String(20);
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_CITPLA_csaF : Integer;
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_COLCAS_csaF : Integer;
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_COPIAS_FT_csaF : Integer;
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_COPIAS_GR_csaF : Integer;
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_DECJUR_csaF : Integer;
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_ENSUNC_csaF : Integer;
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_EPP_csaF : Integer;
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_EXCLUSIV_csaF : Integer;
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_FICSINT_csaF : Integer;
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_FICTECN_csaF : Integer;
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_IMPESP_csaF : Integer;
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_PALETI_csaF : Integer;
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_REQCIT_csaF : Integer;
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_REQIND_csaF : Integer;
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_ROTESP_csaF : Integer;
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_SOTANO_csaF : Integer;
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_TERMO_csaF : Integer;
  @odata.Type : 'Edm.Byte'
  @sap.visible : 'false'
  @sap.label : 'Control campos de IU'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.filterable : 'false'
  @sap.is.extension.field : 'true'
  ZZ1_TIEMPO_csaF : Integer;
  to_PartnerFunction : Association to many API_BUSINESS_PARTNER.A_CustSalesPartnerFunc {  };
  to_SalesAreaTax : Association to many API_BUSINESS_PARTNER.A_CustomerSalesAreaTax {  };
  to_SalesAreaText : Association to many API_BUSINESS_PARTNER.A_CustomerSalesAreaText {  };
  to_SlsAreaAddrDepdntInfo : Association to many API_BUSINESS_PARTNER.A_CustSlsAreaAddrDepdntInfo {  };
};

@cds.external : true
@cds.persistence.skip : true
@sap.deletable : 'false'
@sap.content.version : '1'
@sap.label : 'Impuesto área de ventas'
entity API_BUSINESS_PARTNER.A_CustomerSalesAreaTax {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cliente'
  @sap.quickinfo : 'Número de cliente'
  key Customer : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Organización ventas'
  @sap.quickinfo : 'Organización de ventas'
  key SalesOrganization : String(4) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Canal distr. cli/Mat'
  @sap.quickinfo : 'Canal de distribución maestro de clientes y materiales'
  key DistributionChannel : String(2) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Sector'
  key Division : String(2) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'País/Región salida'
  @sap.quickinfo : 'País/región de salida (del/de la cual se envía la mercancía)'
  key DepartureCountry : String(3) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cl.cond.det.imptos.'
  @sap.quickinfo : 'Cl.cond.det.impuestos (ImpVolNeg, IVA, etc.)'
  key CustomerTaxCategory : String(4) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Clasificación fiscal'
  @sap.quickinfo : 'Clasificación fiscal para el deudor'
  CustomerTaxClassification : String(1);
  to_SlsAreaAddrDepdntTax : Association to many API_BUSINESS_PARTNER.A_CustSlsAreaAddrDepdntTaxInfo {  };
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Texto de área de ventas de cliente'
entity API_BUSINESS_PARTNER.A_CustomerSalesAreaText {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cliente'
  @sap.quickinfo : 'Número de cliente'
  key Customer : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Organización ventas'
  @sap.quickinfo : 'Organización de ventas'
  key SalesOrganization : String(4) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Canal distribución'
  @sap.quickinfo : 'Canal de distribución'
  key DistributionChannel : String(2) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Sector'
  key Division : String(2) not null;
  @sap.label : 'Idioma'
  @sap.quickinfo : 'Clave de idioma'
  key Language : String(2) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'ID texto'
  @sap.quickinfo : 'ID de texto'
  key LongTextID : String(4) not null;
  @sap.label : 'String'
  @sap.heading : ''
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.sortable : 'false'
  @sap.filterable : 'false'
  LongText : String;
};

@cds.external : true
@cds.persistence.skip : true
@sap.creatable : 'false'
@sap.content.version : '1'
@sap.label : 'Agrupación de impuestos de cliente'
entity API_BUSINESS_PARTNER.A_CustomerTaxGrouping {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cliente'
  @sap.quickinfo : 'Número de cliente'
  key Customer : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Categ.fiscal'
  @sap.quickinfo : 'Indicador de categoría para indicador de impuestos'
  key CustomerTaxGroupingCode : String(3) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº cert.exenc.'
  @sap.quickinfo : 'Número del certificado de exención'
  CustTaxGrpExemptionCertificate : String(15);
  @sap.label : 'Tasa exención'
  CustTaxGroupExemptionRate : Decimal(5, 2);
  @sap.display.format : 'Date'
  @sap.label : 'Exento de'
  @sap.quickinfo : 'Fecha de inicio de exención'
  CustTaxGroupExemptionStartDate : Date;
  @sap.display.format : 'Date'
  @sap.label : 'Exención hasta'
  @sap.quickinfo : 'Fecha fin de la exención'
  CustTaxGroupExemptionEndDate : Date;
  @sap.display.format : 'Date'
  @sap.label : 'Sujeto de'
  CustTaxGroupSubjectedStartDate : Date;
  @sap.display.format : 'Date'
  @sap.label : 'Sujeto a'
  CustTaxGroupSubjectedEndDate : Date;
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Texto de cliente'
entity API_BUSINESS_PARTNER.A_CustomerText {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cliente'
  @sap.quickinfo : 'Número de cliente'
  key Customer : String(10) not null;
  @sap.label : 'Idioma'
  @sap.quickinfo : 'Clave de idioma'
  key Language : String(2) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'ID texto'
  @sap.quickinfo : 'ID de texto'
  key LongTextID : String(4) not null;
  @sap.label : 'String'
  @sap.heading : ''
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.sortable : 'false'
  @sap.filterable : 'false'
  LongText : String;
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Punto de carga de cliente'
entity API_BUSINESS_PARTNER.A_CustomerUnloadingPoint {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cliente'
  @sap.quickinfo : 'Número de cliente'
  key Customer : String(10) not null;
  @sap.label : 'Puesto descarga'
  @sap.quickinfo : 'Puesto de descarga'
  key UnloadingPointName : String(25) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Calendario cliente'
  @sap.quickinfo : 'Calendario de fábrica del cliente'
  CustomerFactoryCalenderCode : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Horas de recepción'
  @sap.quickinfo : 'ID-Horas de recepción de mercancía (Número propuesto)'
  BPGoodsReceivingHoursCode : String(3);
  @sap.label : 'Lugar descarga defec'
  @sap.quickinfo : 'Lugar de descarga por defecto'
  IsDfltBPUnloadingPoint : Boolean;
  @sap.label : 'Lunes'
  @sap.quickinfo : 'Recepción de mercancía: Lunes por la mañana desde...'
  MondayMorningOpeningTime : Time;
  @sap.label : 'Lunes'
  @sap.quickinfo : 'Hoar de recepción de mercancía: lunes a la mañana hasta...'
  MondayMorningClosingTime : Time;
  @sap.label : 'Lunes'
  @sap.quickinfo : 'Hora de recepción de mercancía: lunes a la tarde desde...'
  MondayAfternoonOpeningTime : Time;
  @sap.label : 'Lunes'
  @sap.quickinfo : 'Hora de recepción de mercancía: lunes a la tarde hasta...'
  MondayAfternoonClosingTime : Time;
  @sap.label : 'Martes'
  @sap.quickinfo : 'Hora de recepción de mercancía: martes a la mañana desde...'
  TuesdayMorningOpeningTime : Time;
  @sap.label : 'Martes'
  @sap.quickinfo : 'Hoara de recepción de mercancía: martes a la mañana hasta...'
  TuesdayMorningClosingTime : Time;
  @sap.label : 'Martes'
  @sap.quickinfo : 'Hora de recepción de mercancía: martes a la tarde desde...'
  TuesdayAfternoonOpeningTime : Time;
  @sap.label : 'Martes'
  @sap.quickinfo : 'Hora de recepción de mercancía: martes a la tarde hasta...'
  TuesdayAfternoonClosingTime : Time;
  @sap.label : 'Miércoles'
  @sap.quickinfo : 'Hora de recepción de mercancía: miércoles a la mañana desde'
  WednesdayMorningOpeningTime : Time;
  @sap.label : 'Miércoles'
  @sap.quickinfo : 'Hora de recepción de mercancía: miércoles a la mañana hasta'
  WednesdayMorningClosingTime : Time;
  @sap.label : 'Miércoles'
  @sap.quickinfo : 'Hora de recepción de mercancía: miércoles a la tarde desde'
  WednesdayAfternoonOpeningTime : Time;
  @sap.label : 'Miércoles'
  @sap.quickinfo : 'Hora de recepción de mercancía: miércoles a la tarde hasta'
  WednesdayAfternoonClosingTime : Time;
  @sap.label : 'Jueves'
  @sap.quickinfo : 'Hora de recepción de mercancía: jueves a la mañana desde...'
  ThursdayMorningOpeningTime : Time;
  @sap.label : 'Jueves'
  @sap.quickinfo : 'Hora de recepción de mercancía: jueves a la mañana hasta...'
  ThursdayMorningClosingTime : Time;
  @sap.label : 'Jueves'
  @sap.quickinfo : 'Hora de recepción de mercancía: jueves a la tarde desde...'
  ThursdayAfternoonOpeningTime : Time;
  @sap.label : 'Jueves'
  @sap.quickinfo : 'Hora de recepción de mercancía: jueves a la tarde hasta...'
  ThursdayAfternoonClosingTime : Time;
  @sap.label : 'Viernes'
  @sap.quickinfo : 'Hora de recepción de mercancía: viernes a la mañana desde...'
  FridayMorningOpeningTime : Time;
  @sap.label : 'Viernes'
  @sap.quickinfo : 'Hora de recepción de mercancía: viernes a la mañana hasta...'
  FridayMorningClosingTime : Time;
  @sap.label : 'Viernes'
  @sap.quickinfo : 'Hora de recepción de mercancía: viernes a la tarde desde...'
  FridayAfternoonOpeningTime : Time;
  @sap.label : 'Viernes'
  @sap.quickinfo : 'Hora de recepción de mercancía: viernes a la tarde hasta...'
  FridayAfternoonClosingTime : Time;
  @sap.label : 'Sábado'
  @sap.quickinfo : 'Horarios de recepción mercancías: Sábados mañana desde...'
  SaturdayMorningOpeningTime : Time;
  @sap.label : 'Sábado'
  @sap.quickinfo : 'Horarios recepción de mercancías: Sábados mañana hasta...'
  SaturdayMorningClosingTime : Time;
  @sap.label : 'Sábado'
  @sap.quickinfo : 'Horarios recepción de mercancías: Sábados tarde desde...'
  SaturdayAfternoonOpeningTime : Time;
  @sap.label : 'Sábado'
  @sap.quickinfo : 'Horarios recepción de mercancías: Sábados tarde hasta ...'
  SaturdayAfternoonClosingTime : Time;
  @sap.label : 'Domingo'
  @sap.quickinfo : 'Hora de recepción de mercancía: domingo a la mañana desde...'
  SundayMorningOpeningTime : Time;
  @sap.label : 'Domingo'
  @sap.quickinfo : 'Hora de recepción de mercancía: domingo a la tarde hasta...'
  SundayMorningClosingTime : Time;
  @sap.label : 'Domingo'
  @sap.quickinfo : 'Hora de recepción de mercancía: domingo a la mañana desde...'
  SundayAfternoonOpeningTime : Time;
  @sap.label : 'Domingo'
  @sap.quickinfo : 'Hora de recepción de mercancía: domingo a la tarde hasta...'
  SundayAfternoonClosingTime : Time;
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Retención de impuestos'
entity API_BUSINESS_PARTNER.A_CustomerWithHoldingTax {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cliente'
  @sap.quickinfo : 'Número de cliente'
  key Customer : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Sociedad'
  key CompanyCode : String(4) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Tipo de retenciones'
  @sap.quickinfo : 'Indicador para tipo de retenciones'
  key WithholdingTaxType : String(2) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Indicador ret.'
  @sap.quickinfo : 'Indicador de retención'
  WithholdingTaxCode : String(2);
  @sap.label : 'Autor.a autorreten.'
  @sap.quickinfo : 'Indicador: ¿Autorizado a autorretención de impuestos?'
  WithholdingTaxAgent : Boolean;
  @sap.display.format : 'Date'
  @sap.label : 'autoriz.p.reten.de'
  @sap.quickinfo : 'autorizado para la retención de impuestos a partir de'
  ObligationDateBegin : Date;
  @sap.display.format : 'Date'
  @sap.label : 'autoriz.reten.hasta'
  @sap.quickinfo : 'autorización de retención de impuestos hasta'
  ObligationDateEnd : Date;
  @sap.display.format : 'UpperCase'
  @sap.label : 'NIF'
  @sap.quickinfo : 'Número de identificación fiscal'
  WithholdingTaxNumber : String(16);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº de exención'
  @sap.quickinfo : 'Número del certificado de exención'
  WithholdingTaxCertificate : String(25);
  @sap.label : 'Tipo de exención'
  WithholdingTaxExmptPercent : Decimal(5, 2);
  @sap.display.format : 'Date'
  @sap.label : 'Fe.inicio exención'
  @sap.quickinfo : 'Fecha de inicio de la exención'
  ExemptionDateBegin : Date;
  @sap.display.format : 'Date'
  @sap.label : 'Fecha fin exención'
  @sap.quickinfo : 'Fecha del fin de la exención'
  ExemptionDateEnd : Date;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Motivo de exención'
  ExemptionReason : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Autorización'
  @sap.quickinfo : 'Grupo autorizaciones'
  AuthorizationGroup : String(4);
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Funciones de interlocutor de ventas'
entity API_BUSINESS_PARTNER.A_CustSalesPartnerFunc {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cliente'
  @sap.quickinfo : 'Número de cliente'
  key Customer : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Organización ventas'
  @sap.quickinfo : 'Organización de ventas'
  key SalesOrganization : String(4) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Canal distribución'
  @sap.quickinfo : 'Canal de distribución'
  key DistributionChannel : String(2) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Sector'
  key Division : String(2) not null;
  @sap.display.format : 'NonNegative'
  @sap.label : 'Contador interlocut.'
  @sap.quickinfo : 'Contador de interlocutor'
  key PartnerCounter : String(3) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Función de socio'
  key PartnerFunction : String(2) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Proveedor'
  @sap.quickinfo : 'Número de cuenta del proveedor o acreedor'
  BPCustomerNumber : String(10);
  @sap.label : 'Nombre de socio'
  @sap.quickinfo : 'Nombre de socio según cliente (centro, almacén)'
  CustomerPartnerDescription : String(30);
  @sap.label : 'Interl. por defecto'
  @sap.quickinfo : 'Interlocutor por defecto'
  DefaultPartner : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Proveedor'
  @sap.quickinfo : 'Número de cuenta del proveedor o acreedor'
  Supplier : String(10);
  @sap.display.format : 'NonNegative'
  @sap.label : 'Número de personal'
  PersonnelNumber : String(8);
  @sap.display.format : 'NonNegative'
  @sap.label : 'Persona de contacto'
  @sap.quickinfo : 'Número de la persona de contacto'
  ContactPerson : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº dirección'
  @sap.quickinfo : 'Número dirección interloc.comercial (de BUT020)'
  AddressID : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Autorización'
  @sap.quickinfo : 'Grupo autorizaciones'
  AuthorizationGroup : String(4);
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Info dependiente de dirección de área de ventas de cliente'
entity API_BUSINESS_PARTNER.A_CustSlsAreaAddrDepdntInfo {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cliente'
  @sap.quickinfo : 'Número de cliente'
  key Customer : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Organización ventas'
  @sap.quickinfo : 'Organización de ventas'
  key SalesOrganization : String(4) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Canal distribución'
  @sap.quickinfo : 'Canal de distribución'
  key DistributionChannel : String(2) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Sector'
  key Division : String(2) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº dirección'
  @sap.quickinfo : 'Número dirección interloc.comercial (de BUT020)'
  key AddressID : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Incoterms'
  @sap.quickinfo : 'Incoterms parte 1'
  IncotermsClassification : String(3);
  @sap.label : 'Ubicac.incoterms 1'
  @sap.quickinfo : 'Ubicación de incoterms 1'
  IncotermsLocation1 : String(70);
  @sap.label : 'Ubic.incoterms 2'
  @sap.quickinfo : 'Ubicación de incoterms 2'
  IncotermsLocation2 : String(70);
  @sap.label : 'UUID de ubicación'
  IncotermsSupChnLoc1AddlUUID : UUID;
  @sap.label : 'UUID de ubicación'
  IncotermsSupChnLoc2AddlUUID : UUID;
  @sap.label : 'UUID de ubicación'
  IncotermsSupChnDvtgLocAddlUUID : UUID;
  @sap.display.format : 'UpperCase'
  @sap.label : 'BloqEntÁreaVtas'
  @sap.quickinfo : 'Bloqueo de entrega para cliente (nivel comercial)'
  DeliveryIsBlocked : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Oficina de ventas'
  SalesOffice : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo de vendedores'
  SalesGroup : String(3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cond.expedición'
  @sap.quickinfo : 'Condiciones de expedición'
  ShippingCondition : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Centro suministrador'
  @sap.quickinfo : 'Centro suministrador (propio o externo)'
  SupplyingPlant : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Versión de Incoterms'
  IncotermsVersion : String(4);
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Información fiscal depend.dirección de ár.ventas cliente'
entity API_BUSINESS_PARTNER.A_CustSlsAreaAddrDepdntTaxInfo {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cliente'
  @sap.quickinfo : 'Número de cliente'
  key Customer : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Organización ventas'
  @sap.quickinfo : 'Organización de ventas'
  key SalesOrganization : String(4) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Canal distr. cli/Mat'
  @sap.quickinfo : 'Canal de distribución maestro de clientes y materiales'
  key DistributionChannel : String(2) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Sector'
  key Division : String(2) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº dirección'
  @sap.quickinfo : 'Número dirección interloc.comercial (de BUT020)'
  key AddressID : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'País/Región salida'
  @sap.quickinfo : 'País/región de salida (del/de la cual se envía la mercancía)'
  key DepartureCountry : String(3) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cl.cond.det.imptos.'
  @sap.quickinfo : 'Cl.cond.det.impuestos (ImpVolNeg, IVA, etc.)'
  key CustomerTaxCategory : String(4) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Clasificación fiscal'
  @sap.quickinfo : 'Clasificación fiscal para el deudor'
  CustomerTaxClassification : String(1);
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Info dependiente de dirección de punto descarga de cliente'
entity API_BUSINESS_PARTNER.A_CustUnldgPtAddrDepdntInfo {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cliente'
  @sap.quickinfo : 'Número de cliente'
  key Customer : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº dirección'
  @sap.quickinfo : 'Número dirección interloc.comercial (de BUT020)'
  key AddressID : String(10) not null;
  @sap.label : 'Puesto descarga'
  @sap.quickinfo : 'Puesto de descarga'
  key UnloadingPointName : String(25) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Calendario cliente'
  @sap.quickinfo : 'Calendario de fábrica del cliente'
  CustomerFactoryCalenderCode : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Horas de recepción'
  @sap.quickinfo : 'ID-Horas de recepción de mercancía (Número propuesto)'
  BPGoodsReceivingHoursCode : String(3);
  @sap.label : 'Lugar descarga defec'
  @sap.quickinfo : 'Lugar de descarga por defecto'
  IsDfltBPUnloadingPoint : Boolean;
  @sap.label : 'Lunes'
  @sap.quickinfo : 'Recepción de mercancía: Lunes por la mañana desde...'
  MondayMorningOpeningTime : Time;
  @sap.label : 'Lunes'
  @sap.quickinfo : 'Hoar de recepción de mercancía: lunes a la mañana hasta...'
  MondayMorningClosingTime : Time;
  @sap.label : 'Lunes'
  @sap.quickinfo : 'Hora de recepción de mercancía: lunes a la tarde desde...'
  MondayAfternoonOpeningTime : Time;
  @sap.label : 'Lunes'
  @sap.quickinfo : 'Hora de recepción de mercancía: lunes a la tarde hasta...'
  MondayAfternoonClosingTime : Time;
  @sap.label : 'Martes'
  @sap.quickinfo : 'Hora de recepción de mercancía: martes a la mañana desde...'
  TuesdayMorningOpeningTime : Time;
  @sap.label : 'Martes'
  @sap.quickinfo : 'Hoara de recepción de mercancía: martes a la mañana hasta...'
  TuesdayMorningClosingTime : Time;
  @sap.label : 'Martes'
  @sap.quickinfo : 'Hora de recepción de mercancía: martes a la tarde desde...'
  TuesdayAfternoonOpeningTime : Time;
  @sap.label : 'Martes'
  @sap.quickinfo : 'Hora de recepción de mercancía: martes a la tarde hasta...'
  TuesdayAfternoonClosingTime : Time;
  @sap.label : 'Miércoles'
  @sap.quickinfo : 'Hora de recepción de mercancía: miércoles a la mañana desde'
  WednesdayMorningOpeningTime : Time;
  @sap.label : 'Miércoles'
  @sap.quickinfo : 'Hora de recepción de mercancía: miércoles a la mañana hasta'
  WednesdayMorningClosingTime : Time;
  @sap.label : 'Miércoles'
  @sap.quickinfo : 'Hora de recepción de mercancía: miércoles a la tarde desde'
  WednesdayAfternoonOpeningTime : Time;
  @sap.label : 'Miércoles'
  @sap.quickinfo : 'Hora de recepción de mercancía: miércoles a la tarde hasta'
  WednesdayAfternoonClosingTime : Time;
  @sap.label : 'Jueves'
  @sap.quickinfo : 'Hora de recepción de mercancía: jueves a la mañana desde...'
  ThursdayMorningOpeningTime : Time;
  @sap.label : 'Jueves'
  @sap.quickinfo : 'Hora de recepción de mercancía: jueves a la mañana hasta...'
  ThursdayMorningClosingTime : Time;
  @sap.label : 'Jueves'
  @sap.quickinfo : 'Hora de recepción de mercancía: jueves a la tarde desde...'
  ThursdayAfternoonOpeningTime : Time;
  @sap.label : 'Jueves'
  @sap.quickinfo : 'Hora de recepción de mercancía: jueves a la tarde hasta...'
  ThursdayAfternoonClosingTime : Time;
  @sap.label : 'Viernes'
  @sap.quickinfo : 'Hora de recepción de mercancía: viernes a la mañana desde...'
  FridayMorningOpeningTime : Time;
  @sap.label : 'Viernes'
  @sap.quickinfo : 'Hora de recepción de mercancía: viernes a la mañana hasta...'
  FridayMorningClosingTime : Time;
  @sap.label : 'Viernes'
  @sap.quickinfo : 'Hora de recepción de mercancía: viernes a la tarde desde...'
  FridayAfternoonOpeningTime : Time;
  @sap.label : 'Viernes'
  @sap.quickinfo : 'Hora de recepción de mercancía: viernes a la tarde hasta...'
  FridayAfternoonClosingTime : Time;
  @sap.label : 'Sábado'
  @sap.quickinfo : 'Horarios de recepción mercancías: Sábados mañana desde...'
  SaturdayMorningOpeningTime : Time;
  @sap.label : 'Sábado'
  @sap.quickinfo : 'Horarios recepción de mercancías: Sábados mañana hasta...'
  SaturdayMorningClosingTime : Time;
  @sap.label : 'Sábado'
  @sap.quickinfo : 'Horarios recepción de mercancías: Sábados tarde desde...'
  SaturdayAfternoonOpeningTime : Time;
  @sap.label : 'Sábado'
  @sap.quickinfo : 'Horarios recepción de mercancías: Sábados tarde hasta ...'
  SaturdayAfternoonClosingTime : Time;
  @sap.label : 'Domingo'
  @sap.quickinfo : 'Hora de recepción de mercancía: domingo a la mañana desde...'
  SundayMorningOpeningTime : Time;
  @sap.label : 'Domingo'
  @sap.quickinfo : 'Hora de recepción de mercancía: domingo a la tarde hasta...'
  SundayMorningClosingTime : Time;
  @sap.label : 'Domingo'
  @sap.quickinfo : 'Hora de recepción de mercancía: domingo a la mañana desde...'
  SundayAfternoonOpeningTime : Time;
  @sap.label : 'Domingo'
  @sap.quickinfo : 'Hora de recepción de mercancía: domingo a la tarde hasta...'
  SundayAfternoonClosingTime : Time;
};

@cds.external : true
@cds.persistence.skip : true
@sap.creatable : 'false'
@sap.deletable : 'false'
@sap.content.version : '1'
@sap.label : 'Proveedor de mercancías'
entity API_BUSINESS_PARTNER.A_Supplier {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Proveedor'
  @sap.quickinfo : 'Número de cuenta del proveedor o acreedor'
  key Supplier : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Receptor alter.pago'
  @sap.quickinfo : 'Número de cuenta del receptor alternativo del pago'
  AlternativePayeeAccountNumber : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Autorización'
  @sap.quickinfo : 'Grupo autorizaciones'
  AuthorizationGroup : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Creado por'
  @sap.quickinfo : 'Nombre del responsable que ha añadido el objeto'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  CreatedByUser : String(12);
  @sap.display.format : 'Date'
  @sap.label : 'Creado el'
  @sap.quickinfo : 'Fecha de creación del registro'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  CreationDate : Date;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cliente'
  @sap.quickinfo : 'Número de cliente'
  Customer : String(10);
  @sap.label : 'Bloqueo pago'
  @sap.quickinfo : 'Bloqueo de pago'
  PaymentIsBlockedForSupplier : Boolean;
  @sap.label : 'Bloqueo contab.'
  @sap.quickinfo : 'Bloqueo contabilización central'
  PostingIsBlocked : Boolean;
  @sap.label : 'Bloq.compras'
  @sap.quickinfo : 'Bloqueo de compras asignado centralizadamente'
  PurchasingIsBlocked : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo de cuentas'
  @sap.quickinfo : 'Grupo de cuentas acreedor'
  SupplierAccountGroup : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nombre del proveedor'
  @sap.quickinfo : 'Nombre completo del proveedor'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  SupplierFullName : String(220);
  @sap.label : 'Nombre de proveedor'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  SupplierName : String(80);
  @sap.display.format : 'UpperCase'
  @sap.label : 'N.I.F. comunitario'
  @sap.quickinfo : 'Número de identificación fiscal comunitario'
  VATRegistration : String(20);
  @sap.display.format : 'Date'
  @sap.label : 'Fecha de nacimiento'
  @sap.quickinfo : 'Fecha de nacimiento de la persona sujeta a retención'
  BirthDate : Date;
  @sap.label : 'Nº ubicación int.'
  @sap.quickinfo : 'Número de ubicación internacional concatenado'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  ConcatenatedInternationalLocNo : String(20);
  @sap.label : 'Pet.borrado'
  @sap.quickinfo : 'Petición borrado central p.registro maestro'
  DeletionIndicator : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Domicilio fiscal'
  @sap.quickinfo : 'Número de cuenta del registro maestro con domicilio fiscal'
  FiscalAddress : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Ramo'
  @sap.quickinfo : 'Clave de ramo industrial'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  Industry : String(4);
  @sap.display.format : 'NonNegative'
  @sap.label : 'Núm.ubicación int.1'
  @sap.quickinfo : 'International Location Number (parte 1)'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  InternationalLocationNumber1 : String(7);
  @sap.display.format : 'NonNegative'
  @sap.label : 'Núm.ubicación int.2'
  @sap.quickinfo : 'Número de ubicación internacional (parte 2)'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  InternationalLocationNumber2 : String(5);
  @sap.display.format : 'NonNegative'
  @sap.label : 'Dígito de control'
  @sap.quickinfo : 'Dígito de control para el Nº de empresa internacional'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  InternationalLocationNumber3 : String(1);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Persona física'
  IsNaturalPerson : String(1);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Motivo de pago'
  PaymentReason : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Clase de impuesto'
  ResponsibleType : String(2);
  @sap.display.format : 'Date'
  @sap.label : 'Sist.QM válido a'
  @sap.quickinfo : 'Fecha de validez de la certificación'
  SuplrQltyInProcmtCertfnValidTo : Date;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Sistema QM real'
  @sap.quickinfo : 'Sistema de gestión calidad del proveedor'
  SuplrQualityManagementSystem : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Clave de grupo'
  SupplierCorporateGroup : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Función de bloqueo'
  @sap.quickinfo : 'Función que se bloqueará'
  SupplierProcurementBlock : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº ident.fis.1'
  @sap.quickinfo : 'Número de identificación fiscal 1'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  TaxNumber1 : String(16);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº ident.fis.2'
  @sap.quickinfo : 'Número de identificación fiscal suplementario'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  TaxNumber2 : String(11);
  @sap.display.format : 'UpperCase'
  @sap.label : 'NIF 3'
  @sap.quickinfo : 'Número identificación fiscal 3'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  TaxNumber3 : String(18);
  @sap.display.format : 'UpperCase'
  @sap.label : 'NIF 4'
  @sap.quickinfo : 'Número identificación fiscal 4'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  TaxNumber4 : String(18);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Número fiscal 5'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  TaxNumber5 : String(60);
  @sap.display.format : 'UpperCase'
  @sap.label : 'N.I.F.'
  @sap.quickinfo : 'Número identificación fiscal en Hacienda competente'
  TaxNumberResponsible : String(18);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Tipo NIF'
  @sap.quickinfo : 'Tipo de número de identificación fiscal'
  TaxNumberType : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Relevante para ARE'
  @sap.quickinfo : 'Indicador proveedor relevante para acuse de recibo entrega'
  SuplrProofOfDelivRlvtCode : String(1);
  @sap.label : 'Partición impuestos'
  @sap.quickinfo : 'Indicador: Valor fiscal repartido'
  BR_TaxIsSplit : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Clave instrucción'
  @sap.quickinfo : 'Clave de instrucción para ISD'
  DataExchangeInstructionKey : String(2);
  to_SupplierCompany : Association to many API_BUSINESS_PARTNER.A_SupplierCompany {  };
  to_SupplierPurchasingOrg : Association to many API_BUSINESS_PARTNER.A_SupplierPurchasingOrg {  };
  to_SupplierText : Association to many API_BUSINESS_PARTNER.A_SupplierText {  };
};

@cds.external : true
@cds.persistence.skip : true
@sap.deletable : 'false'
@sap.content.version : '1'
@sap.label : 'Empresa proveedora'
entity API_BUSINESS_PARTNER.A_SupplierCompany {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Proveedor'
  @sap.quickinfo : 'Número de cuenta del proveedor o acreedor'
  key Supplier : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Sociedad'
  key CompanyCode : String(4) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Autorización'
  @sap.quickinfo : 'Grupo autorizaciones'
  AuthorizationGroup : String(4);
  @sap.label : 'Nombre sociedad GL'
  @sap.quickinfo : 'Denominación de la sociedad o la sociedad GL'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  CompanyCodeName : String(25);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Bloqueo de pago'
  @sap.quickinfo : 'Clave de bloqueo para el pago'
  PaymentBlockingReason : String(1);
  @sap.label : 'Bloq.contab.p.soc.'
  @sap.quickinfo : 'Bloqueo de contabilización para sociedad'
  SupplierIsBlockedForPosting : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Abrev.respons.'
  @sap.quickinfo : 'Abreviatura del pesponsable de contabilidad'
  AccountingClerk : String(2);
  @sap.label : 'Telefaz encargado'
  @sap.quickinfo : 'Telefax del encargado en el interlocutor comercial'
  AccountingClerkFaxNumber : String(31);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Teléfono responsable'
  @sap.quickinfo : 'Número de teléfono del responsable en interlocutor comercial'
  AccountingClerkPhoneNumber : String(30);
  @sap.label : 'Responsable acreedor'
  @sap.quickinfo : 'Responsable en acreedor'
  SupplierClerk : String(15);
  @sap.label : 'Direc.Internet resp.'
  @sap.quickinfo : 'Dirección Internet del responsable del interlocutor comerc.'
  SupplierClerkURL : String(130);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Vías de pago'
  @sap.quickinfo : 'Lista de las vías de pago a tener en cuenta'
  PaymentMethodsList : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Motivo de pago'
  PaymentReason : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Condiciones de pago'
  @sap.quickinfo : 'Clave de condiciones de pago'
  PaymentTerms : String(4);
  @sap.label : 'Compensar con deudor'
  @sap.quickinfo : 'Indicador: ¿Compensación entre deudor y acreedor?'
  ClearCustomerSupplier : Boolean;
  @sap.label : 'Trat. no centraliz.'
  @sap.quickinfo : 'Indicador: Tratamiento no centralizado'
  IsToBeLocallyProcessed : Boolean;
  @sap.label : 'Pago único'
  @sap.quickinfo : 'Indicador: Pagar todas las partidas individualmente'
  ItemIsToBePaidSeparately : Boolean;
  @sap.label : 'Aviso pago por EDI'
  @sap.quickinfo : 'Indicador: Enviar avisos de pago por EDI'
  PaymentIsToBeSentByEDI : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Banco propio'
  @sap.quickinfo : 'Clave breve para banco propio'
  HouseBank : String(5);
  @sap.label : 'Días hasta cobro'
  @sap.quickinfo : 'Tiempo previsto hasta cobro del cheque'
  CheckPaidDurationInDays : Decimal(3, 0);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Moneda'
  @sap.quickinfo : 'Clave de moneda'
  @sap.semantics : 'currency-code'
  Currency : String(5);
  @sap.unit : 'Currency'
  @sap.label : 'Límite de efectos'
  @sap.quickinfo : 'Límite de efectos (en moneda local)'
  BillOfExchLmtAmtInCoCodeCrcy : Decimal(14, 3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Ntra.cta. c/acreed.'
  @sap.quickinfo : 'Nuestra cuenta con el acreedor'
  SupplierClerkIDBySupplier : String(12);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cuenta asociada'
  @sap.quickinfo : 'Cuenta asociada en la contabilidad principal'
  ReconciliationAccount : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Indicador intereses'
  @sap.quickinfo : 'Indicador de intereses'
  InterestCalculationCode : String(2);
  @sap.display.format : 'Date'
  @sap.label : 'Últ.fecha clv.'
  @sap.quickinfo : 'Fecha clave del último cálculo de intereses'
  InterestCalculationDate : Date;
  @sap.display.format : 'NonNegative'
  @sap.label : 'Ritmo ints.'
  @sap.quickinfo : 'Ritmo del cálculo de intereses en meses'
  IntrstCalcFrequencyInMonths : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Central'
  @sap.quickinfo : 'Número de cuenta de la central'
  SupplierHeadOffice : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Receptor alter.pago'
  @sap.quickinfo : 'Número de cuenta del receptor alternativo del pago'
  AlternativePayee : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Clave clasificación'
  @sap.quickinfo : 'Clave para clasificar por números de asignación'
  LayoutSortingRule : String(3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo tolerancia'
  @sap.quickinfo : 'Grupo de tolerancia p.interlocutor comercial/cta.may.'
  APARToleranceGroup : String(4);
  @sap.display.format : 'Date'
  @sap.label : 'Fecha certificación'
  @sap.quickinfo : 'Fecha de certificación'
  SupplierCertificationDate : Date;
  @sap.label : 'Nota interior cuenta'
  @sap.quickinfo : 'Nota'
  SupplierAccountNote : String(30);
  @sap.display.format : 'UpperCase'
  @sap.label : 'País/Reg.retención'
  @sap.quickinfo : 'Clave de país/región de retención de impuestos'
  WithholdingTaxCountry : String(3);
  @sap.label : 'Petic.borrado soc.'
  @sap.quickinfo : 'Petición de borrado p.registro maestro (nivel de sociedad)'
  DeletionIndicator : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo de tesorería'
  CashPlanningGroup : String(10);
  @sap.label : 'Verif. factura doble'
  @sap.quickinfo : 'Nota de verificación para facturas duplicadas o abonos'
  IsToBeCheckedForDuplicates : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Indicador minorías'
  @sap.quickinfo : 'Indicador de minorías'
  MinorityGroup : String(3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo de cuentas'
  @sap.quickinfo : 'Grupo de cuentas acreedor'
  SupplierAccountGroup : String(4);
  to_CompanyText : Association to many API_BUSINESS_PARTNER.A_SupplierCompanyText {  };
  to_Supplier : Association to API_BUSINESS_PARTNER.A_Supplier {  };
  to_SupplierDunning : Association to many API_BUSINESS_PARTNER.A_SupplierDunning {  };
  to_SupplierWithHoldingTax : Association to many API_BUSINESS_PARTNER.A_SupplierWithHoldingTax {  };
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Texto de empresa de proveedor'
entity API_BUSINESS_PARTNER.A_SupplierCompanyText {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Proveedor'
  @sap.quickinfo : 'Número de cuenta del proveedor o acreedor'
  key Supplier : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Sociedad'
  key CompanyCode : String(4) not null;
  @sap.label : 'Idioma'
  @sap.quickinfo : 'Clave de idioma'
  key Language : String(2) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'ID texto'
  @sap.quickinfo : 'ID de texto'
  key LongTextID : String(4) not null;
  @sap.label : 'String'
  @sap.heading : ''
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.sortable : 'false'
  @sap.filterable : 'false'
  LongText : String;
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Reclamación de proveedor'
entity API_BUSINESS_PARTNER.A_SupplierDunning {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Proveedor'
  @sap.quickinfo : 'Número de cuenta del proveedor o acreedor'
  key Supplier : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Sociedad'
  key CompanyCode : String(4) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Área de reclamación'
  key DunningArea : String(2) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Bloqueo reclam.'
  @sap.quickinfo : 'Bloqueo de reclamación'
  DunningBlock : String(1);
  @sap.display.format : 'NonNegative'
  @sap.label : 'Nivel reclamación'
  @sap.quickinfo : 'Nivel de reclamación'
  DunningLevel : String(1);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Proced.reclamación'
  @sap.quickinfo : 'Procedimiento de reclamación'
  DunningProcedure : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Receptor reclamación'
  @sap.quickinfo : 'Número de cuenta del receptor de la reclamación'
  DunningRecipient : String(10);
  @sap.display.format : 'Date'
  @sap.label : 'Última reclam.'
  @sap.quickinfo : 'Fecha de la última reclamación'
  LastDunnedOn : Date;
  @sap.display.format : 'Date'
  @sap.label : 'Reclam.judicial del'
  @sap.quickinfo : 'Fecha del procedimiento de reclamación judicial'
  LegDunningProcedureOn : Date;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Respons.reclamación'
  @sap.quickinfo : 'Responsable de la reclamación'
  DunningClerk : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Autorización'
  @sap.quickinfo : 'Grupo autorizaciones'
  AuthorizationGroup : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo de cuentas'
  @sap.quickinfo : 'Grupo de cuentas acreedor'
  SupplierAccountGroup : String(4);
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Funciones de interlocutor de compras'
entity API_BUSINESS_PARTNER.A_SupplierPartnerFunc {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Proveedor'
  @sap.quickinfo : 'Número de cuenta del proveedor o acreedor'
  key Supplier : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Organización compras'
  @sap.quickinfo : 'Organización de compras'
  key PurchasingOrganization : String(4) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Surt.parc.proveedor'
  @sap.quickinfo : 'Surtido parcial de proveedor'
  key SupplierSubrange : String(6) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Centro'
  key Plant : String(4) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Función de socio'
  key PartnerFunction : String(2) not null;
  @sap.display.format : 'NonNegative'
  @sap.label : 'Contador interlocut.'
  @sap.quickinfo : 'Contador de interlocutor'
  key PartnerCounter : String(3) not null;
  @sap.label : 'Interl. por defecto'
  @sap.quickinfo : 'Interlocutor por defecto'
  DefaultPartner : Boolean;
  @sap.display.format : 'Date'
  @sap.label : 'Fecha de creación'
  @sap.quickinfo : 'Fecha de creación del registro'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  CreationDate : Date;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Autor'
  @sap.quickinfo : 'Nombre del responsable que ha añadido el objeto'
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  CreatedByUser : String(12);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Ref.a proveedor'
  @sap.quickinfo : 'Referencia a otro proveedor'
  ReferenceSupplier : String(10);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Autorización'
  @sap.quickinfo : 'Grupo autorizaciones'
  AuthorizationGroup : String(4);
};

@cds.external : true
@cds.persistence.skip : true
@sap.deletable : 'false'
@sap.content.version : '1'
@sap.label : 'Organización de compras'
entity API_BUSINESS_PARTNER.A_SupplierPurchasingOrg {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Proveedor'
  @sap.quickinfo : 'Número de cuenta del proveedor'
  key Supplier : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Organización compras'
  @sap.quickinfo : 'Organización de compras'
  key PurchasingOrganization : String(4) not null;
  @sap.label : 'Autofacturac.devol.'
  @sap.quickinfo : 'Autofacturación para posiciones devolución'
  AutomaticEvaluatedRcptSettlmt : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Gr.esquema proveedor'
  @sap.quickinfo : 'Grupo para esquema de cálculo (proveedor)'
  CalculationSchemaGroupCode : String(2);
  @sap.label : 'PetBorrOrgComp'
  @sap.quickinfo : 'Indicador de borrado para proveedor a nivel de compras'
  DeletionIndicator : Boolean;
  @sap.label : 'Autofacturación'
  EvaldReceiptSettlementIsActive : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Incoterms'
  @sap.quickinfo : 'Incoterms parte 1'
  IncotermsClassification : String(3);
  @sap.label : 'Incoterms, parte 2'
  IncotermsTransferLocation : String(28);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Versión de Incoterms'
  IncotermsVersion : String(4);
  @sap.label : 'Ubicac.incoterms 1'
  @sap.quickinfo : 'Ubicación de incoterms 1'
  IncotermsLocation1 : String(70);
  @sap.label : 'Ubic.incoterms 2'
  @sap.quickinfo : 'Ubicación de incoterms 2'
  IncotermsLocation2 : String(70);
  @sap.label : 'UUID de ubicación'
  IncotermsSupChnLoc1AddlUUID : UUID;
  @sap.label : 'UUID de ubicación'
  IncotermsSupChnLoc2AddlUUID : UUID;
  @sap.label : 'UUID de ubicación'
  IncotermsSupChnDvtgLocAddlUUID : UUID;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Modo de transporte'
  @sap.quickinfo : 'Modo de transporte en frontera (Intrastat)'
  IntrastatCrsBorderTrMode : String(1);
  @sap.label : 'Verific.fact.base EM'
  @sap.quickinfo : 'Indicador p.verificación de facturas sobre la base de la EM'
  InvoiceIsGoodsReceiptBased : Boolean;
  @sap.label : 'Ver.fact.rel.serv.'
  @sap.quickinfo : 'Indicador para verificación facturas relativas a servicios'
  InvoiceIsMMServiceEntryBased : Boolean;
  @sap.label : 'Plazo entrega prev.'
  @sap.quickinfo : 'Plazo de entrega previsto en días'
  MaterialPlannedDeliveryDurn : Decimal(3, 0);
  @sap.unit : 'PurchaseOrderCurrency'
  @sap.label : 'Valor mínimo pedido'
  @sap.quickinfo : 'Valor mínimo de pedido'
  MinimumOrderAmount : Decimal(14, 3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Condiciones de pago'
  @sap.quickinfo : 'Clave de condiciones de pago'
  PaymentTerms : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Ciclo planificación'
  @sap.quickinfo : 'Ciclo de planificación'
  PlanningCycle : String(3);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Control fecha precio'
  @sap.quickinfo : 'Control fecha determinación del precio'
  PricingDateControl : String(1);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Perfil ctrl.PROACT'
  @sap.quickinfo : 'Perfil p.transferir datos de materiales mediante IDOC PROACT'
  ProdStockAndSlsDataTransfPrfl : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo un.medida'
  @sap.quickinfo : 'Grupo de unidades de medida'
  ProductUnitGroup : String(4);
  @sap.label : 'Pedido automático'
  @sap.quickinfo : 'Pedido automático permitido'
  PurOrdAutoGenerationIsAllowed : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Moneda de pedido'
  @sap.semantics : 'currency-code'
  PurchaseOrderCurrency : String(5);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo de compras'
  PurchasingGroup : String(3);
  @sap.label : 'BloqCompOrgComp'
  @sap.quickinfo : 'Bloqueo de compras a nivel de organización de compras'
  PurchasingIsBlockedForSupplier : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Perfil de redondeo'
  RoundingProfile : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cond.expedición'
  @sap.quickinfo : 'Condiciones de expedición'
  ShippingCondition : String(2);
  @sap.label : 'Casilla de selección'
  @sap.heading : ''
  SuplrDiscountInKindIsGranted : Boolean;
  @sap.label : 'Revaloración'
  @sap.quickinfo : 'Revaloración permitida'
  SuplrInvcRevalIsAllowed : Boolean;
  @sap.label : 'Gestión liquidación'
  @sap.quickinfo : 'Indicador: Relevante para gestión de liquidación'
  SuplrIsRlvtForSettlmtMgmt : Boolean;
  @sap.label : 'Determinación precio'
  @sap.quickinfo : 'Ind.: Relevante p.determ.precios (jerarquía proveedores)'
  SuplrPurgOrgIsRlvtForPriceDetn : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Indicador ABC'
  SupplierABCClassificationCode : String(1);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Cuenta en proveedor'
  @sap.quickinfo : 'Nuestro número de cuenta en proveedor'
  SupplierAccountNumber : String(12);
  @sap.label : 'Proveedor devol.'
  @sap.quickinfo : 'Indica si se trata de devolución con gestión de expedición'
  SupplierIsReturnsSupplier : Boolean;
  @sap.label : 'Teléfono'
  @sap.quickinfo : 'Número de teléfono del proveedor'
  SupplierPhoneNumber : String(16);
  @sap.label : 'Vendedor'
  @sap.quickinfo : 'Vendedor responsable en el proveedor'
  SupplierRespSalesPersonName : String(30);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Control confirmación'
  @sap.quickinfo : 'Clave de control de confirmaciones'
  SupplierConfirmationControlKey : String(4);
  @sap.label : 'Oblig.confirmación'
  @sap.quickinfo : 'Indicador de obligación de confirmación de pedido'
  IsOrderAcknRqd : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Autorización'
  @sap.quickinfo : 'Grupo autorizaciones'
  AuthorizationGroup : String(4);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Grupo de cuentas'
  @sap.quickinfo : 'Grupo de cuentas acreedor'
  SupplierAccountGroup : String(4);
  to_PartnerFunction : Association to many API_BUSINESS_PARTNER.A_SupplierPartnerFunc {  };
  to_PurchasingOrgText : Association to many API_BUSINESS_PARTNER.A_SupplierPurchasingOrgText {  };
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Texto de la organización de compras'
entity API_BUSINESS_PARTNER.A_SupplierPurchasingOrgText {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Proveedor'
  @sap.quickinfo : 'Número de cuenta del proveedor o acreedor'
  key Supplier : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Organización compras'
  @sap.quickinfo : 'Organización de compras'
  key PurchasingOrganization : String(4) not null;
  @sap.label : 'Idioma'
  @sap.quickinfo : 'Clave de idioma'
  key Language : String(2) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'ID texto'
  @sap.quickinfo : 'ID de texto'
  key LongTextID : String(4) not null;
  @sap.label : 'String'
  @sap.heading : ''
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.sortable : 'false'
  @sap.filterable : 'false'
  LongText : String;
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Texto del proveedor'
entity API_BUSINESS_PARTNER.A_SupplierText {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Proveedor'
  @sap.quickinfo : 'Número de cuenta del proveedor o acreedor'
  key Supplier : String(10) not null;
  @sap.label : 'Idioma'
  @sap.quickinfo : 'Clave de idioma'
  key Language : String(2) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'ID texto'
  @sap.quickinfo : 'ID de texto'
  key LongTextID : String(4) not null;
  @sap.label : 'String'
  @sap.heading : ''
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.sortable : 'false'
  @sap.filterable : 'false'
  LongText : String;
};

@cds.external : true
@cds.persistence.skip : true
@sap.content.version : '1'
@sap.label : 'Retención de impuestos de empresa'
entity API_BUSINESS_PARTNER.A_SupplierWithHoldingTax {
  @sap.display.format : 'UpperCase'
  @sap.label : 'Proveedor'
  @sap.quickinfo : 'Número de cuenta del proveedor o acreedor'
  key Supplier : String(10) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Sociedad'
  key CompanyCode : String(4) not null;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Tipo de retenciones'
  @sap.quickinfo : 'Indicador para tipo de retenciones'
  key WithholdingTaxType : String(2) not null;
  @sap.display.format : 'Date'
  @sap.label : 'Fe.inicio exención'
  @sap.quickinfo : 'Fecha de inicio de la exención'
  ExemptionDateBegin : Date;
  @sap.display.format : 'Date'
  @sap.label : 'Fecha fin exención'
  @sap.quickinfo : 'Fecha del fin de la exención'
  ExemptionDateEnd : Date;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Motivo de exención'
  ExemptionReason : String(2);
  @sap.label : 'Sujeto a reten.'
  @sap.quickinfo : 'Indicador: ¿Sujeto a retención?'
  IsWithholdingTaxSubject : Boolean;
  @sap.display.format : 'UpperCase'
  @sap.label : 'Categoría retención'
  @sap.quickinfo : 'Categoría de retención de un acreedor'
  RecipientType : String(2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Nº de exención'
  @sap.quickinfo : 'Número del certificado de exención'
  WithholdingTaxCertificate : String(25);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Indicador ret.'
  @sap.quickinfo : 'Indicador de retención'
  WithholdingTaxCode : String(2);
  @sap.label : 'Tipo de exención'
  WithholdingTaxExmptPercent : Decimal(5, 2);
  @sap.display.format : 'UpperCase'
  @sap.label : 'NIF'
  @sap.quickinfo : 'Número de identificación fiscal'
  WithholdingTaxNumber : String(16);
  @sap.display.format : 'UpperCase'
  @sap.label : 'Autorización'
  @sap.quickinfo : 'Grupo autorizaciones'
  AuthorizationGroup : String(4);
};

@cds.external : true
@cds.persistence.skip : true
@sap.creatable : 'false'
@sap.updatable : 'false'
@sap.deletable : 'false'
@sap.content.version : '1'
@sap.countable : 'true'
@sap.searchable : 'true'
@sap.semantics : 'aggregate'
@sap.value.list : 'true'
entity API_BUSINESS_PARTNER.ZZ1_GRPCLIENT1Set {
  @sap.text : 'Description'
  @sap.label : 'Grupo de clientes 1'
  key Code : String(2) not null;
  @sap.label : 'Descripción'
  Description : String(60);
};

@cds.external : true
@cds.persistence.skip : true
@sap.creatable : 'false'
@sap.updatable : 'false'
@sap.deletable : 'false'
@sap.content.version : '1'
@sap.countable : 'true'
@sap.searchable : 'true'
@sap.semantics : 'aggregate'
@sap.value.list : 'true'
entity API_BUSINESS_PARTNER.ZZ1_SOTANO2Set {
  @sap.text : 'Description'
  @sap.label : 'Sótano'
  key Code : String(1) not null;
  @sap.label : 'Descripción'
  Description : String(60);
};

