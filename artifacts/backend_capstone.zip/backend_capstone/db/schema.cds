namespace cap;

using { cuid, managed } from '@sap/cds/common';

// ═══════════════════════════════════════════════════════
// PRODUCTS — Catálogo de productos
// Solo lectura desde el servicio. Se carga vía CSV seed.
// ═══════════════════════════════════════════════════════
entity Products : cuid {
  code        : String(20)    @mandatory;
  description : String(100)   @mandatory;
  unitPrice   : Decimal(12,2);
  currency    : String(3)     default 'PEN';
  stock       : Integer       default 0;
  active      : Boolean       default true;
}

// ═══════════════════════════════════════════════════════
// ORDERS — Órdenes de venta
// Entidad principal del sistema.
// La mixin 'managed' agrega: createdAt, createdBy,
//   modifiedAt, modifiedBy — auditoria automática.
// ═══════════════════════════════════════════════════════
entity Orders : cuid, managed {
  orderNumber   : String(20);
  customer      : String(80)    @mandatory;
  customerEmail : String(120);
  amount        : Decimal(15,2) default 0;
  currency      : String(3)     default 'PEN';
  status        : String(20)    default 'PENDING';
  remarks       : String(500);
  approvalID    : String(36);
  approvedBy    : String(80);
  approvedAt    : Timestamp;
  items         : Composition of many OrderItems
                    on items.order = $self;
}

// ═══════════════════════════════════════════════════════
// ORDER ITEMS — Ítems de la orden
// Composición: no existen sin su orden padre.
// Al borrar Orders, CAP borra sus OrderItems en cascada.
// ═══════════════════════════════════════════════════════
entity OrderItems : cuid {
  order   : Association to Orders;
  product : Association to Products;
  qty     : Integer       default 1;
  price   : Decimal(12,2);
  subtotal: Decimal(15,2);
}