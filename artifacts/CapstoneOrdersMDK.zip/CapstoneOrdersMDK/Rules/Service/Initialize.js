export default function Initialize(context) {

    // Perform pre data initialization task

    // Initialize all your Data sources
    let _com_axigma_capstone_orders = context.executeAction('/CapstoneOrdersMDK/Actions/com_axigma_capstone_orders/Service/InitializeOnline.action');

    //You can add more service initialize actions here

    return Promise.all([_com_axigma_capstone_orders]).then(() => {
        // After Initializing the DB connections

        // Display successful initialization  message to the user
        return context.executeAction({

            "Name": "/CapstoneOrdersMDK/Actions/GenericToastMessage.action",
            "Properties": {
                "Message": "Application Services Initialized",
                "Animated": true,
                "Duration": 1,
                "IsIconHidden": true,
                "NumberOfLines": 1
            }
        });
    }).catch(() => {
        return false;
    });
}