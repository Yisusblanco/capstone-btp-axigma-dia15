export default function GetStatusIcon(context) {
  var status = context.binding ? context.binding.status : undefined;
  switch (status) {
    case 'PENDING':
      return 'sap-icon://pending';
    case 'IN_APPROVAL':
      return 'sap-icon://process';
    case 'APPROVED':
      return 'sap-icon://accept';
    case 'REJECTED':
      return 'sap-icon://decline';
    default:
      return 'sap-icon://question-mark';
  }
}