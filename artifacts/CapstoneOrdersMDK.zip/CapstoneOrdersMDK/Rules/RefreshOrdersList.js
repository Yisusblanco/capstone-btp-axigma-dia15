export default function RefreshOrdersList(pageProxy) {
  try {
    var table = pageProxy.getControl('SectionedTable0');

    // Inspeccionar qué devuelve dataQueryBuilder
    var qb = table.dataQueryBuilder();
    console.log('queryBuilder type:', typeof qb);
    if (qb) {
      console.log('queryBuilder proto methods:', Object.getOwnPropertyNames(Object.getPrototypeOf(qb)).join(', '));
      console.log('queryBuilder own keys:', Object.keys(qb).join(', '));
    }
  } catch (e) {
    console.log('EXCEPTION:', e.message);
  }
}