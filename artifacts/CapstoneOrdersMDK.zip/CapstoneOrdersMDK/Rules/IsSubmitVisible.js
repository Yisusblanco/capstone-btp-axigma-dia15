// IsSubmitVisible.js
export default function IsSubmitVisible(clientAPI) {
    const page = clientAPI.getPageProxy();
    const status = page.getPropertyValue('status');
    console.log('IsSubmitVisible status:', status);
    return status === 'PENDING';
}