export default function SetSubmitVisibility(pageProxy) {
  try {
    var binding = pageProxy._context && pageProxy._context.binding;
    var status = binding ? binding.status : undefined;
    pageProxy.setActionBarItemVisible(0, status === 'PENDING');
  } catch (e) {
    console.log('ERROR in SetSubmitVisibility:', e.message);
  }
}