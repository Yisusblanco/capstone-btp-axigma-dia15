export default function GetCreateOrderError(clientAPI) {
  var actionResult = clientAPI.getActionResult('CreateOrder');
  return 'DEBUG: ' + JSON.stringify(actionResult);
}