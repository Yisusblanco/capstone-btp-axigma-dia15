{
	"_Name": "CapstoneOrdersMDK",
	"Version": "/CapstoneOrdersMDK/Globals/Application/AppDefinition_Version.global",
	"MainPage": "/CapstoneOrdersMDK/Pages/Main.page",
	"OnLaunch": "/CapstoneOrdersMDK/Rules/Service/Initialize.js",
	"OnWillUpdate": "/CapstoneOrdersMDK/Rules/Application/OnWillUpdate.js",
	"OnDidUpdate": "/CapstoneOrdersMDK/Rules/Service/Initialize.js",
	"Styles": "/CapstoneOrdersMDK/Styles/Styles.less",
	"Localization": "/CapstoneOrdersMDK/i18n/i18n.properties",
	"_SchemaVersion": "26.3"
}